﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Diff_Sel
{
    public class ButtonScript : MonoBehaviour
    {
        //ボタンタイプ
        enum BUTTON_TYPE
        {
            TITLE,
            DIFFICULTY_SELECT,
            TUTORIAL,
            EASY,
            NORMAL,
            HARD,
            VERY_HARD,
            RETRY,
            NEXT,
            QUIT,

        }

        
        [SerializeField]
        BUTTON_TYPE difficulty;

		[SerializeField]
		GameObject Select;

		// Use this for initialization
		void Start()
        {
        }

        // Update is called once per frame
        void Update()
        {

        }

        public void ChangeScene()
        {
            Scene scene = SceneManager.GetActiveScene();
			Singleton<SoundManagerScript>.instance.PlaySE("se_start", Select);
            switch(difficulty)
            {
                case BUTTON_TYPE.TITLE:
                    SceneManager.LoadSceneAsync(0);
                    break;
                case BUTTON_TYPE.DIFFICULTY_SELECT:
                    SceneManager.LoadSceneAsync(1);
                    break;
                case BUTTON_TYPE.TUTORIAL:
                    SceneManager.LoadSceneAsync(2);
                    break;
                case BUTTON_TYPE.EASY:
                    SceneManager.LoadSceneAsync(3);
                    break;
                case BUTTON_TYPE.NORMAL:
                    SceneManager.LoadSceneAsync(4);
                    break;
                case BUTTON_TYPE.HARD:
                    SceneManager.LoadSceneAsync(5);
                    break;
                case BUTTON_TYPE.VERY_HARD:
                    SceneManager.LoadSceneAsync(6);
                    break;
                case BUTTON_TYPE.RETRY:
                    SceneManager.LoadSceneAsync(scene.buildIndex);
                    break;
                case BUTTON_TYPE.NEXT:
                    SceneManager.LoadSceneAsync(scene.buildIndex + 1);
                    break;
                case BUTTON_TYPE.QUIT:
                    Application.Quit();
                    break;
                default:
                    break;
            }
        }
    }
}
