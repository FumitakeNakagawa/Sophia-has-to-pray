﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


namespace Tutorial
{
    public class GameManager_TutorialScript : MonoBehaviour
    {
        //難易度
        public enum DIFFICULTY
        {
            TUTORIAL,
            EASY,
            NORMAL,
            HARD,
            VERY_HARD
        }

        //エネミー(子)の管理
        [System.Serializable]
        struct s_Enemy
        {

            //[HideInInspector]
            public GameObject gameObject;
            //[HideInInspector]
            public bool GameOverFlg;

            public Enemy2Script enemy2Script;
            //アニメーター
            public EnemyAnimatorScript animator;
        }

        //ステート
        public enum STATE
        {
            STANDBY,
            PLAY,
            CLEAR,
            SLERP,
            GAME_OVER
        }

        public enum TUTORIAL_STATE
        {
            ASK_PLAY_TUTORIAL,

            HOW_TO_PLAY_AND_LOOK_AROUND,
            HOW_TO_CHANGE_LIGHT_POWER,
            HOW_TO_PRAY,
            
            PLAYING_LOOK_AROUND,
            PLAYING_CHANGE_LIGHT_POWER,
            PLAYING_PRAY,

            REPLAY_PRAY,
            REPLAY_TUTORIAL,
        }

        //ステート
        public STATE state;
        public TUTORIAL_STATE tutorialState;

        //難易度選択
        [SerializeField]
        DIFFICULTY difficulty;

        [SerializeField]
        Transform GoalPoint;

        [System.Serializable]
        struct Player
        {
            [SerializeField]
            public GameObject playerObj;
            [SerializeField]
            public GameObject lampObj;

            public TouchScript touchScript;
            public SwipeScript swipeScript;
            public PlayerScript playerScript;
            public LightScript lightScript;
        }

        [Space, SerializeField]
        Player player;

        [SerializeField]
        FadeScript fadeScript;

        //敵まとめてるオブジェクト
        [Space, SerializeField]
        public GameObject Enemy;
        //敵単体オブジェクト
        [SerializeField]
        s_Enemy[] enemies;


        [Space, Space]
        [SerializeField]
        GameObject Pinch;

        public int frameCount;
        private int frameDraw;      //描画用
        public float nextTime;
        private GUIStyle labelFPS;
        float timeEnvironment;          //環境音のなる間隔


        public Quaternion DeadRotation;
        int DeadIndex;
        float t;
        float handSpeed;
        float speedUp;

		[SerializeField]
		GameObject Shout;

		public STATE GetState() { return state; }
        public void SetState(STATE s) { state = s; }


        public DIFFICULTY GetDifficulty() { return difficulty; }

        public bool stopMove;


        public bool deadEnd;
        // Use this for initialization
        void Start()
        {
            stopMove = true;
            Singleton<SoundManagerScript>.instance.UnMuteSound();
            Singleton<SoundManagerScript>.instance.PlayBGM("bgm_main", 0.0f, true);
            timeEnvironment = 6.0f;
            frameCount = 0;
            nextTime = Time.time + 1;

            labelFPS = new GUIStyle();
            labelFPS.fontSize = Screen.height / 50;
            labelFPS.normal.textColor = Color.white;
            frameDraw = 0;

            state = STATE.STANDBY;
            tutorialState = TUTORIAL_STATE.ASK_PLAY_TUTORIAL;
            player.swipeScript = player.playerObj.GetComponent<SwipeScript>();
            player.playerScript = player.playerObj.GetComponent<PlayerScript>();
            player.touchScript = player.playerObj.GetComponent<TouchScript>();


            int size = 0;
            while (true)
            {
                if (Enemy.transform.Find(size.ToString()))
                    size++;
                else
                    break;
            }
            enemies = new s_Enemy[size];

            for (int index = 0; index < size; index++)
            {
                enemies[index].gameObject = Enemy.transform.Find(index.ToString()).gameObject;
                enemies[index].GameOverFlg = false;
                enemies[index].enemy2Script = enemies[index].gameObject.GetComponent<Enemy2Script>();
                enemies[index].animator = enemies[index].gameObject.GetComponent<EnemyAnimatorScript>();
                enemies[index].gameObject.SetActive(false);
                enemies[index].enemy2Script.spotLight.enabled = false;
            }

            t = 0;
            handSpeed = 0;
            speedUp = 0;

            DeadRotation = new Quaternion(0, 0, 0, 1);

            ScriptEnabled(false);

            deadEnd = false;
        }

        // Update is called once per frame
        void Update()
        {
			Singleton<SoundManagerScript>.instance.Update();

			switch (state)
            {
                case STATE.STANDBY:

                    if (fadeScript.IsStartFadeEnd())
                    {
                        ScriptEnabled(true);
                        foreach (var it in enemies)
                            it.gameObject.SetActive(true);
                        state = STATE.PLAY;

                    }

                    break;
                case STATE.PLAY:
                    //print(state);
                    Playing();
                    break;
                case STATE.SLERP:
                    print(state);
                    speedUp += 0.03f;
                    t += speedUp * Time.deltaTime;
                    t = Mathf.Min(1, t);
                    t = Mathf.Max(t, 0);
                    player.playerObj.transform.rotation = Quaternion.Slerp(player.playerObj.transform.rotation, Quaternion.LookRotation((enemies[DeadIndex].gameObject.transform.position + new Vector3(0, player.playerObj.transform.position.y, 0)) - player.playerObj.transform.position), t);
                    if (!deadEnd && t >= 1)
                    {
                        deadEnd = true;
                        player.lampObj.SetActive(false);
                        Singleton<SoundManagerScript>.instance.MuteSound();
						Singleton<SoundManagerScript>.instance.PlaySE("se_fearend", gameObject);
						Singleton<SoundManagerScript>.instance.PlaySE("se_shout", Shout);
						enemies[DeadIndex].enemy2Script.spotLight.enabled = true;
                        state = STATE.GAME_OVER;
                    }
                    break;
                case STATE.GAME_OVER:
                    print(state);
                    enemies[DeadIndex].animator.TriggerGameOverFlg();
                    break;
                case STATE.CLEAR:
                    print(state);
                    player.playerScript.enabled = false;
                    Pinch.SetActive(false);
                    CheckUP();
                    break;
            }

            if (state >= STATE.SLERP)
            {
                if (handSpeed < 1)
                {
                    handSpeed += speedUp * Time.deltaTime;
                    player.lampObj.transform.Translate(handSpeed, -handSpeed, 0);
                }
            }

            //Debug.Log(enemies[1].gameObject.transform.position.ToString());

            //SE
            Singleton<SoundManagerScript>.instance.Update();
            PlaySE(gameObject, "Beats", "se_beats");


            //フレームレート
            frameCount++;
            if (Time.time >= nextTime)
            {
                // 1秒経ったらFPSを表示
                //Debug.Log("FPS : " + frameCount);
                //frameCount = 0;
                //nextTime += 1;
            }


        }

        void CheckUP()
        {
            switch (difficulty)
            {
                case DIFFICULTY.TUTORIAL:

                    break;
                case DIFFICULTY.EASY:
                    Title.Title.difficult[0].state = Title.Title.Difficult.STATE.CLEAR;
                    break;
                case DIFFICULTY.NORMAL:
                    Title.Title.difficult[1].state = Title.Title.Difficult.STATE.CLEAR;
                    break;
                case DIFFICULTY.HARD:
                    Title.Title.difficult[2].state = Title.Title.Difficult.STATE.CLEAR;
                    break;
            }
        }

        void Goal()
        {
            if (player.playerObj.transform.position.z >= GoalPoint.position.z)
            {
                state = STATE.CLEAR;
            }
        }

        void PlaySE(GameObject gameManager, string nameObj, string nameSE)

        {
            GameObject se = null;
            foreach (Transform child in gameManager.transform)
            {
                if (child.name == nameObj)
                {
                    se = child.gameObject;
                    break;
                }
            }
            if (se == null) return;
            if (player.touchScript.IsPray())
            {
                if (se.GetComponent<AudioSource>().pitch < 1.4f) se.GetComponent<AudioSource>().pitch += 0.0002f;
                Singleton<SoundManagerScript>.instance.PlaySE(nameSE, se);
            }
            else
            {
                se.GetComponent<AudioSource>().pitch = 1.0f;
            }
        }

        //void OnGUI()
        //{
        //    if (Time.time >= nextTime)
        //    {
        //        // 1秒経ったらFPSを表示
        //        string text = string.Empty;
        //        text = string.Format("FPS : " + frameCount);

        //        //GUI.Label(new Rect(0, 0, 200, 200), text, labelFPS);

        //        frameDraw = frameCount;
        //        frameCount = 0;
        //        nextTime += 1;
        //    }
        //    else
        //    {
        //        string text = string.Empty;
        //        text = string.Format("FPS : " + frameDraw);

        //        GUI.Label(new Rect(0, 60, 200, 200), text, labelFPS);
        //    }

        //    string str = stopMove.ToString() ;
        //    GUI.Label(new Rect(0, 0, 400, 400), str, labelFPS);
        //}



        private void ScriptEnabled(bool val)
        {
            player.touchScript.enabled = val;
            player.swipeScript.enabled = val;
            player.playerScript.enabled = val;
            player.lightScript.enabled = val;
            
        }



        void Playing()
        {
            for (int index = 0; index < enemies.Length; index++)
            {
                enemies[index].GameOverFlg = enemies[index].gameObject.GetComponent<Enemy2Script>().isGameOver();
                if (enemies[index].GameOverFlg)
                {
                    if (player.swipeScript.GetNowIndex() == SwipeScript.DIRECT.CENTER && index == 0)
                        t = 1.0f;
                    else if (player.swipeScript.GetNowIndex() == SwipeScript.DIRECT.LEFT && index == 1)
                        t = 1.0f;
                    else if (player.swipeScript.GetNowIndex() == SwipeScript.DIRECT.RIGHT && index == 2)
                        t = 1.0f;
                    else if (player.swipeScript.GetNowIndex() == SwipeScript.DIRECT.DOWN && index == 3)
                        t = 1.0f;


                    enemies[index].gameObject.transform.rotation = Quaternion.LookRotation(player.playerObj.transform.position - (enemies[index].gameObject.transform.position + new Vector3(0, player.playerObj.transform.position.y, 0)));

                    DeadRotation = player.playerObj.transform.rotation;
                    DeadIndex = index;

                    state = STATE.SLERP;

                    player.lightScript.ZeroCandle();

                    Pinch.SetActive(false);
                    player.playerScript.enabled = false;
                    break;
                }
            }

            Goal();
        }
    }
}