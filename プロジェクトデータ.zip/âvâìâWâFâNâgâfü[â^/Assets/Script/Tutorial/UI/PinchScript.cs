﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Tutorial
{
    [ExecuteInEditMode]
    public class PinchScript : MonoBehaviour
    {
        [System.Serializable]
        struct Data
        {
            [SerializeField]
            public float dist;
            [SerializeField]
            public float fadeSpeed;
            [SerializeField]
            public float minFadeValue;
            [SerializeField]
            public float maxFadeValue;
        }
        [SerializeField]
        Data[] PinchData;


        [SerializeField]
        GameObject Player;

        [SerializeField]
        GameObject EnemyRoot;

        [SerializeField]
        GameObject[] enemies;

        Image image;


        Color color;

        [SerializeField]
        float minDist;

        [SerializeField]
        int pinchIndex;

        public int GetPinchIndex() { return pinchIndex; }
        bool fade;
        // Use this for initialization
        void Start()
        {
            minDist = float.MaxValue;
            image = GetComponent<Image>();
            color = new Color(1, 1, 1, 0);


            int size = 0;
            while (true)
            {
                if (EnemyRoot.transform.Find(size.ToString()))
                    size++;
                else
                    break;
            }
            enemies = new GameObject[size];

            for (size = 0; size < enemies.Length; size++)
                enemies[size] = EnemyRoot.transform.Find(size.ToString()).gameObject;

            fade = false;
            pinchIndex = -1;
        }

        // Update is called once per frame
        void Update()
        {
            minDist = MinDistance();
            Debug.LogError(minDist.ToString());
            Compare();
            if (pinchIndex >= 0)
            {

                if (!fade)
                    color.a += PinchData[pinchIndex].fadeSpeed * Time.deltaTime;
                else
                    color.a -= PinchData[pinchIndex].fadeSpeed * Time.deltaTime;

                color.a = Mathf.Max(color.a, PinchData[pinchIndex].minFadeValue);
                color.a = Mathf.Min(color.a, PinchData[pinchIndex].maxFadeValue);

                if (color.a == PinchData[pinchIndex].minFadeValue || color.a == PinchData[pinchIndex].maxFadeValue)
                    fade = !fade;
            }
            image.color = color;
        }

        float MinDistance()
        {
            float dist = float.MaxValue;

            foreach (var it in enemies)
            {
                float d = Vector3.Distance(Player.transform.position, it.transform.position);
                if (d < dist)
                    dist = d;
            }
            return dist;
        }

        void Compare()
        {
            for (int index = 0; index < PinchData.Length; index++)
            {
                if (minDist > PinchData[0].dist)
                {
                    color.a = 0;
                    pinchIndex = -1;
                    return;
                }
                if (minDist < PinchData[index].dist)
                {
                    pinchIndex = index;
                }
            }
        }
    }
}