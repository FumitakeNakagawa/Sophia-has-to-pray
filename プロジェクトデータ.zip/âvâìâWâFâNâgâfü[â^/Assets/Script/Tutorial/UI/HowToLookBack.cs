﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


namespace Tutorial
{


    public class HowToLookBack : MonoBehaviour
    {
        [SerializeField]
        GameObject Hand;


        [SerializeField]
        Image Manual;

        [SerializeField]
        Sprite[] manualSprites;


        [SerializeField]
        float handSpeed;
        float handMoveDist;

        [SerializeField]
        float fixTimerOffset;
        float fixTimer;
        bool fixHand;

        [SerializeField]
        float maxHandMoveDist;

        [SerializeField]
        Text text;
        [SerializeField]
        Text massage;
        int step;

        [SerializeField]
        GameObject[] children;
        [SerializeField]
        GameObject next;

        [SerializeField, Multiline]
        string[] textOffset;

        [SerializeField]
        GameObject end;

        int textIndex;
        TutorialManagerScript TutorialManager;

        // Use this for initialization
        void Start()
        {
            handMoveDist = float.MaxValue;
            step = 2;
            fixHand = true;
            fixTimer = 0;

            children = new GameObject[gameObject.transform.childCount];

            for (int index = 0; index < children.Length; index++)
            {
                children[index] = gameObject.transform.GetChild(index).gameObject;
                children[index].SetActive(true);
            }

            TutorialManager = gameObject.transform.root.GetComponent<TutorialManagerScript>();
            end.SetActive(false);
        }

        // Update is called once per frame
        void Update()
        {

            switch (step)
            {
                case 0:
                    if (!fixHand)
                        handMoveDist += handSpeed;

                    if (handMoveDist <= maxHandMoveDist)
                        Hand.transform.Translate(new Vector3(handSpeed, 0, 0f));
                    else
                    {

                        fixHand = true;
                        fixTimer += Time.deltaTime;
                        text.text = "右に向く場合";
                        if (fixTimer > fixTimerOffset)
                        {
                            fixHand = false;
                            fixTimer = 0f;
                            //Hand.transform.Translate(new Vector3(-handMoveDist+handSpeed, 0, 0f));
                            handMoveDist = 0;
                            step = 2;
                        }
                    }
                    break;
                case 1:
                    handMoveDist = 0;
                    fixHand = false;
                    fixTimer = 0;
                    Vector2 pos = Hand.gameObject.GetComponent<RectTransform>().anchoredPosition;
                    pos.x = 300;
                    Hand.GetComponent<RectTransform>().anchoredPosition = pos;
                    break;
                case 2:

                    if (!fixHand)
                        handMoveDist += handSpeed;

                    if (handMoveDist <= maxHandMoveDist)
                        Hand.transform.Translate(new Vector3(-handSpeed, 0, 0f));
                    else
                    {
                        text.text = "左に向く場合";
                        fixHand = true;
                        fixTimer += Time.deltaTime;
                        if (fixTimer > fixTimerOffset)
                        {
                            fixHand = false;
                            fixTimer = 0f;
                            //Hand.transform.Translate(new Vector3(handMoveDist - handSpeed, 0, 0f));
                            handMoveDist = 0;
                            step = 0;
                        }
                    }
                    break;
            }
        }


        public void Play()
        {
            textIndex++;
            if (textIndex == textOffset.Length - 1)
                end.SetActive(true);
            else
                end.SetActive(false);
            if (textIndex >= textOffset.Length)
            {
                TutorialManager.GetEnemy(0).enemy2Script.enabled = true;
                TutorialManager.GetEnemy(1).enemy2Script.enabled = true;
                TutorialManager.GetEnemy(2).enemy2Script.enabled = true;
                foreach (var it in children)
                    it.SetActive(false);
                TutorialManager.SetSwipeOn(true);
                gameObject.SetActive(false);
                TutorialManager.GetGameManager().stopMove = false;
                next.SetActive(true);
            }
            else
                massage.text = textOffset[textIndex];
        }
    }
}