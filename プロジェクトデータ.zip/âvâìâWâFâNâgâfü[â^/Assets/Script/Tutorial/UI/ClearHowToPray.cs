﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Tutorial
{
    public class ClearHowToPray : MonoBehaviour
    {

        TutorialManagerScript TutorialManager;

        [SerializeField]
        GameManager_TutorialScript gameManager;

        [SerializeField]
        GameObject[] children;

        [SerializeField, Multiline]
        string[] textOffset;

        [SerializeField]
        Text text;
        int textIndex;

        [SerializeField]
        GameObject next;

        [SerializeField]
        GameObject Comment;
        // Use this for initialization
        void Start()
        {
            TutorialManager = gameObject.transform.root.GetComponent<TutorialManagerScript>();
            children = new GameObject[gameObject.transform.childCount];

            for (int index = 0; index < children.Length; index++)
            {
                children[index] = gameObject.transform.GetChild(index).gameObject;
                children[index].SetActive(false);
            }
        }

        // Update is called once per frame
        void Update()
        {
            Comment.SetActive(false);
            TutorialManager.GetEnemy(0).enemy2Script.enabled = true;
            if (TutorialManager.IsClearPray()&& !TutorialManager.GetTouchScript().IsPray())
            {
                TutorialManager.GetEnemy(0).enemy2Script.enabled = false;

                gameManager.stopMove = true;
                foreach (var it in children)
                        it.SetActive(true);
            }
            text.text = textOffset[textIndex];
        }


        public void Next()
        {
            textIndex++;
            if(textIndex >= textOffset.Length)
            {
                textIndex = 0;
                next.SetActive(true);
                gameManager.stopMove = false;
                TutorialManager.SetFase(TutorialManagerScript.FASE.LOOK_AROUD);
                gameObject.SetActive(false);
            }
        }
    }
}