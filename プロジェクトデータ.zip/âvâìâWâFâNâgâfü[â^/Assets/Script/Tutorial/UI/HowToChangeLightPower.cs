﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Tutorial
{
    public class HowToChangeLightPower : MonoBehaviour
    {

        [SerializeField]
        GameObject Arrow;
        [SerializeField]
        GameObject[] children;

        TutorialManagerScript TutorialManager;

        [SerializeField]
        Slider slider;

        [SerializeField, Multiline]
        string[] textOffset;

        [SerializeField, Multiline]
        string[] textOffsetAfter;

        int textIndex;
        [SerializeField]
        Text text;

        [SerializeField]
        GameObject next;

        [SerializeField]
        GameManager_TutorialScript gameManagr;
        bool clear;

        // Use this for initialization
        void Start()
        {
            children = new GameObject[gameObject.transform.childCount];

            for (int index = 0; index < children.Length; index++)
            {
                children[index] = gameObject.transform.GetChild(index).gameObject;
                children[index].SetActive(true);
            }

            TutorialManager = gameObject.transform.root.GetComponent<TutorialManagerScript>();

        }

        // Update is called once per frame
        void Update()
        {
            if (!clear)
                text.text = textOffset[textIndex];
            else
                text.text = textOffsetAfter[textIndex];
            if (!clear && slider.value == slider.maxValue)
            {
                Singleton<SoundManagerScript>.instance.PlaySE("se_tutorial",gameObject);
                clear = true;
                textIndex = 0;
                foreach (var it in children)
                    if (it.name == "Panel")
                        it.SetActive(true);
            }
        }

        public void Next()
        {
            textIndex++;

            if (!clear)
            {
                if (textIndex == textOffset.Length - 1)
                {
                    slider.interactable = true;
                    foreach (var it in children)
                    {
                        if (it.name == "Panel")
                            it.SetActive(false);
                        Arrow.SetActive(false);

                    }
                }
                if (textIndex >= textOffset.Length)
                {
                    textIndex = textOffset.Length - 1;
                }
            }
            else
            {

                if (textIndex >= textOffsetAfter.Length)
                {
                    textIndex = 0;

                    foreach (var it in children)
                        it.SetActive(false);
                    gameManagr.stopMove = false;
                    gameObject.SetActive(false);
                    next.SetActive(true);
                }
            }
        }


    }
}