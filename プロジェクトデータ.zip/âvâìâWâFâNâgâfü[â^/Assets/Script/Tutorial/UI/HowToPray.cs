﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Tutorial
{

    public class HowToPray : MonoBehaviour
    {

        public Image image;

        [SerializeField]
        Sprite[] sprites;
        int nowPageNumber;

        TutorialManagerScript TutorialManager;

        [SerializeField]
        GameManager_TutorialScript gameManager;

        [SerializeField]
        GameObject[] children;

        [SerializeField]
        float stopDist;

        [SerializeField]
        GameObject Comment;

        [SerializeField]
        GameObject Panel;

        bool teach;
        // Use this for initialization
        void Start()
        {
            nowPageNumber = 0;
            image = transform.Find("Image").gameObject.GetComponent<Image>();
            TutorialManager = gameObject.transform.root.GetComponent<TutorialManagerScript>();
            children = new GameObject[gameObject.transform.childCount];

            for (int index = 0; index < children.Length; index++)
            {
                children[index] = gameObject.transform.GetChild(index).gameObject;
                children[index].SetActive(false);
            }
            Comment.SetActive(false);
            teach = false;
        }

        // Update is called once per frame
        void Update()
        {
            if (!teach)
                TutorialManager.GetEnemy(0).enemy2Script.enabled = true;
            if (!teach && TutorialManager.dist < stopDist)
            {
                TutorialManager.GetEnemy(0).enemy2Script.enabled = false;
                foreach (var it in children)
                    it.SetActive(true);
                Comment.SetActive(false);
                gameManager.stopMove = true;
                teach = true;
            }
            image.sprite = sprites[nowPageNumber];
        }


        public void NextPage()
        {
            nowPageNumber++;
            if (nowPageNumber > sprites.Length - 1)
            {
                //ステート進める
                nowPageNumber = 0;
                image.enabled = false;
                gameManager.stopMove = true;
                TutorialManager.SetPrayOn(true);
                TutorialManager.SetFase(TutorialManagerScript.FASE.PRAY);
                Comment.SetActive(true);
                Panel.SetActive(false);
                //gameObject.SetActive(false);
            }

        }
    }
}