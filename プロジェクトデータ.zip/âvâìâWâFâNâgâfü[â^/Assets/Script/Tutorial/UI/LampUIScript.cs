﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Tutorial
{
    public class LampUIScript : MonoBehaviour
    {
        //[SerializeField]
        //Light light;

        [SerializeField]
        LightScript lightScript;

        [SerializeField, Header("デバッグ用の%表示")]
        float Debug;

        [SerializeField]
        Text text;

        // Use this for initialization
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {
            int val = (int)(lightScript.candle * 100);
            text.text = val+ "%";
        }

    }
}
