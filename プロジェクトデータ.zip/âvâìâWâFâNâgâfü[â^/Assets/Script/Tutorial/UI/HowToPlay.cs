﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Tutorial
{
    public class HowToPlay : MonoBehaviour
    {

        [SerializeField, Multiline]
        string[] textOffset;


        GameObject[] children;

        [SerializeField]
        Text text;

        [SerializeField]
        GameObject next;

        int textIndex;

        TutorialManagerScript TutorialManager;

        bool playSE;
        // Use this for initialization
        void Start()
        {
            playSE = false;
            textIndex = 0;

            children = new GameObject[gameObject.transform.childCount];

            for (int index = 0; index < children.Length; index++)
            {
                children[index] = gameObject.transform.GetChild(index).gameObject;
                children[index].SetActive(true);
            }
            TutorialManager = gameObject.transform.root.GetComponent<TutorialManagerScript>();

        }

        // Update is called once per frame
        void Update()
        {
            if(textIndex <textOffset.Length)
            text.text = textOffset[textIndex];
        }

        public void Next()
        {
            textIndex++;
            if (textIndex >= textOffset.Length)
            {
                if (!playSE)
                {
                    Singleton<SoundManagerScript>.instance.PlaySE("se_tutorial", gameObject);
                    playSE = true;
                    return;
                }
                textIndex = 0;
                next.SetActive(true);
                foreach (var it in children)
                    it.SetActive(false);
                gameObject.SetActive(false);
            }
        }
    }
}
