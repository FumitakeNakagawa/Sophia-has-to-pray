﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Tutorial
{
    public class DirectUI : MonoBehaviour
    {

        Text text;
        [SerializeField]
        SwipeScript swipeScript;
        // Use this for initialization
        void Start()
        {
            text = GetComponent<Text>();
        }

        // Update is called once per frame
        void Update()
        {

            switch (swipeScript.GetNowIndex())
            {
                case SwipeScript.DIRECT.CENTER:
                    text.text = "前";

                    break;

                case SwipeScript.DIRECT.DOWN:
                    text.text = "後";
                    break;

                case SwipeScript.DIRECT.LEFT:
                    text.text = "左";

                    break;

                case SwipeScript.DIRECT.RIGHT:
                    text.text = "右";

                    break;
            }
        }
    }
}
