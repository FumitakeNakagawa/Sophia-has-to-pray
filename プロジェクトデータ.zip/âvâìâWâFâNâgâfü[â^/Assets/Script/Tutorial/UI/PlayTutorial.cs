﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


namespace Tutorial
{
    public class PlayTutorial : MonoBehaviour
    {

        [SerializeField]
        string sceneName; //遷移先のシーン名

        AsyncOperation async;

        [SerializeField]
        Image fade;

        [SerializeField]
        float fadeSpeed;

        //シーン切り替え無効にするため
        [SerializeField]
        FadeScript fadeScript;

        [SerializeField]
        GameObject[] children;

        [SerializeField]
        GameManager_TutorialScript gameManagerScript;

        [SerializeField]
        GameObject next;

        [SerializeField]
        PlayerScript playerScript;
        TutorialManagerScript TutorialManager;
        bool start;
        // Use this for initialization
        void Start()
        {
            start = true;
            children = new GameObject[gameObject.transform.childCount];

            for (int index = 0; index < children.Length; index++)
            {
                children[index] = gameObject.transform.GetChild(index).gameObject;
                children[index].SetActive(false);
            }
            TutorialManager = gameObject.transform.root.GetComponent<TutorialManagerScript>();
            playerScript.enabled = false;
        }

        // Update is called once per frame
        void Update()
        {
            playerScript.enabled = false;

            //ロード完了後のフェードインが終了したとき
            if (start && fadeScript.IsStartFadeEnd())
            {
                foreach (var it in children)
                    it.SetActive(true);
                start = false;
            }

            if (async != null)
            {
                foreach (var it in children)
                    it.SetActive(false);
                Color col = fade.color;
                col.a += fadeSpeed * Time.deltaTime;
                col.a = Mathf.Min(1, col.a);
                fade.color = col;
                if (col.a >= 1f)
                    async.allowSceneActivation = true;
            }
        }


        public void NoPlay()
        {

            StartCoroutine(LoadScene());
            fadeScript.enabled = false;
            //gameObject.SetActive(false);
        }

        public void Play()
        {
            foreach (var it in children)
                it.SetActive(false);
            next.SetActive(true);
            gameObject.SetActive(false);
            playerScript.enabled = true;
        }


        private IEnumerator LoadScene()
        {
            async = SceneManager.LoadSceneAsync(sceneName);
            async.allowSceneActivation = false;
            while (!async.isDone)
            {
                yield return null;
            }
        }
    }
}