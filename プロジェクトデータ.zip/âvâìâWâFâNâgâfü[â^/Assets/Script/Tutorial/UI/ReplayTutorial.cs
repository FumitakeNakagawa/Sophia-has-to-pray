﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Tutorial
{
    public class ReplayTutorial : MonoBehaviour
    {
        [SerializeField]
        string sceneName;

        AsyncOperation async;

        [SerializeField]
        Image fade;

        [SerializeField]
        float fadeSpeed;

        [SerializeField]
        FadeScript fadeScript;

        [SerializeField]
        GameObject[] children;

        TutorialManagerScript TutorialManager;

        [SerializeField]
        PlayerScript playerScript;

        [SerializeField]
        SwipeScript swipeScript;

        [SerializeField]
        GameObject Comment;

        [SerializeField]
        TouchScript touchScript;
        bool start;


        bool[] prayOk = new bool[2];
        float[] prayTimer = new float[2];
        // Use this for initialization
        void Start()
        {
            start = true;
            children = new GameObject[gameObject.transform.childCount];

            for (int index = 0; index < children.Length; index++)
            {
                children[index] = gameObject.transform.GetChild(index).gameObject;
                children[index].SetActive(false);
            }
            TutorialManager = gameObject.transform.root.GetComponent<TutorialManagerScript>();

            for (int index = 0; index < prayOk.Length; index++)
                prayOk[index] = false;
            for (int index = 0; index < prayTimer.Length; index++)
                prayTimer[index] = 0f;

        Comment.SetActive(true);
        }


        // Update is called once per frame
        void Update()
        {
            TutorialManager.GetEnemy(0).gameObject.SetActive(false);

            if (!prayOk[0]&&TutorialManager.GetTouchScript().IsPray() && swipeScript.GetNowIndex() == SwipeScript.DIRECT.LEFT)
            {
                prayTimer[0] += Time.deltaTime;
                TutorialManager.GetEnemy(1).enemy2Script.enabled = true;

                if (prayTimer[0] > 2.0f)
                {
                    TutorialManager.GetEnemy(1).enemy2Script.enabled = false;
                    prayOk[0] = true;
                    Singleton<SoundManagerScript>.instance.PlaySE("se_tutorial", gameObject);
                }

            }
            else
                TutorialManager.GetEnemy(1).enemy2Script.enabled = false;


            if (!prayOk[1] && TutorialManager.GetTouchScript().IsPray() && swipeScript.GetNowIndex() == SwipeScript.DIRECT.RIGHT)
            {
                prayTimer[1] += Time.deltaTime;
                TutorialManager.GetEnemy(2).enemy2Script.enabled = true;

                if (prayTimer[1] > 2.0f)
                {
                    TutorialManager.GetEnemy(2).enemy2Script.enabled = false;
                    prayOk[1] = true;
                    Singleton<SoundManagerScript>.instance.PlaySE("se_tutorial", gameObject);
                }
            }
            else
                TutorialManager.GetEnemy(2).enemy2Script.enabled = false;
                


            //両サイドの敵を追い払った
            if (!TutorialManager.GetTouchScript().IsPray() &&  prayOk[0] && prayOk[1])
            {
                Comment.SetActive(false);

                playerScript.enabled = false;
                swipeScript.enabled = false;
                touchScript.enabled = false;
                TutorialManager.GetGameManager().stopMove = true;
                //フェード開始
                if (start && fadeScript.IsStartFadeEnd())
                {
                    foreach (var it in children)
                        it.SetActive(true);
                    start = false;
                }
                //ロード
                if (async != null)
                {
                    foreach (var it in children)
                        it.SetActive(false);
                    Color col = fade.color;
                    col.a += fadeSpeed * Time.deltaTime;
                    col.a = Mathf.Min(1, col.a);
                    fade.color = col;
                    if (col.a >= 1f)
                        async.allowSceneActivation = true;
                }
            }
        }


        public void RePlay()
        {

            StartCoroutine(LoadScene(SceneManager.GetActiveScene().name));
            fadeScript.enabled = false;

        }

        public void NoPlay()
        {
            StartCoroutine(LoadScene(sceneName));
            fadeScript.enabled = false;
        }


        private IEnumerator LoadScene(string scene)
        {
            async = SceneManager.LoadSceneAsync(scene);
            async.allowSceneActivation = false;
            while (!async.isDone)
            {
                yield return null;
            }
        }
    }
}