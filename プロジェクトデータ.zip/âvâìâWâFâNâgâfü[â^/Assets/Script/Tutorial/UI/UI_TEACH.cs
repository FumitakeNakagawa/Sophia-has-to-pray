﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Tutorial
{
    public class UI_TEACH : MonoBehaviour
    {


        [SerializeField]
        GameObject[] children;

        [SerializeField]
        GameObject next;

        TutorialManagerScript TutorialManager;

        // Use this for initialization
        void Start()
        {
            children = new GameObject[gameObject.transform.childCount];

            for (int index = 0; index < children.Length; index++)
            {
                children[index] = gameObject.transform.GetChild(index).gameObject;
                children[index].SetActive(true);
            }
            TutorialManager = gameObject.transform.root.GetComponent<TutorialManagerScript>();

        }

        // Update is called once per frame
        void Update()
        {

        }


        public void Next()
        {
            next.SetActive(true);
            foreach (var it in children)
                it.SetActive(false);
             gameObject.SetActive(false);
        }
    }
}