﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Tutorial
{
    public class TutorialManagerScript : MonoBehaviour
    {


        bool swipeOn;
        bool prayOn;
        bool lightPowerOn;

        public void SetSwipeOn(bool val) { swipeOn = val; }
        public void SetPrayOn(bool val) { prayOn = val; }
        public void SetLightPowerOn(bool val) { lightPowerOn = val; }

        public bool GetSwipeOn() { return swipeOn; }
        public bool GetPray() { return prayOn; }
        public bool GetLightPower() { return lightPowerOn; }

        bool startTutorial;

        [SerializeField]
        TouchScript touchScript;
        public TouchScript GetTouchScript() { return touchScript; }



        [SerializeField]
        SwipeScript swipeScript;
        

        [SerializeField]
        GameManager_TutorialScript gameManager;
        public GameManager_TutorialScript GetGameManager() { return gameManager; }

        [SerializeField]
        PinchScript pinchScript;
        public PinchScript GetPinchScript() { return pinchScript; }


        [SerializeField]
        GameObject clearLookObj;

        [SerializeField]
        GameObject clearPrayObj;

        [SerializeField]
        GameObject lightPowerObj;

        [SerializeField]
        GameObject PrayObj;

        [SerializeField]
        GameObject player;

        [SerializeField]
        GameObject chappy;

        public float dist;

        [SerializeField]
        float stopDist;

        [SerializeField]
        GameObject enemy;

        float prayTimer;
        bool prayOK;
        //エネミー(子)の管理
        [System.Serializable]
        public struct s_Enemy
        {

            //[HideInInspector]
            public GameObject gameObject;
            //[HideInInspector]
            public bool GameOverFlg;

            public Enemy2Script enemy2Script;
            //アニメーター
            public EnemyAnimatorScript animator;
        }

        s_Enemy[] enemies;
        public s_Enemy GetEnemy(int index) { return enemies[index]; }


        public enum FASE
        {
            LIGHT_POWER,
            PRAY,
            LOOK_AROUD,
            END
        }

        FASE fase;

        bool clearLook;
        public bool IsClearLook() { return clearLook; }

        bool clearPray;
        public bool IsClearPray() { return clearPray; }

        public void SetFase(FASE f) { fase = f; }




        // Use this for initialization
        void Start()
        {
            startTutorial = false;
            clearLook = false;
            fase = FASE.LIGHT_POWER;

            int size = 0;
            while (true)
            {
                if (enemy.transform.Find(size.ToString()))
                    size++;
                else
                    break;
            }

            enemies = new s_Enemy[size];
            //それぞれの敵情報取得
            for (int index = 0; index < size; index++)
            {
                enemies[index].gameObject = enemy.transform.Find(index.ToString()).gameObject;
                enemies[index].GameOverFlg = false;
                enemies[index].enemy2Script = enemies[index].gameObject.GetComponent<Enemy2Script>();
                enemies[index].animator = enemies[index].gameObject.GetComponent<EnemyAnimatorScript>();
                enemies[index].enemy2Script.spotLight.enabled = false;
                enemies[index].enemy2Script.enabled = false;
            }

            prayTimer = 0f;
            prayOK = false;
        }

        // Update is called once per frame
        void Update()
        {
            Debug.Log(fase.ToString());
            dist = Vector3.Distance(player.transform.position, chappy.transform.position);

            switch (fase)
            {
                case FASE.LOOK_AROUD:
                    if (!clearLook && swipeScript.GetNowIndex() != SwipeScript.DIRECT.CENTER)
                    {
                        // clearLook = true;
                        //gameManager.stopMove = false;

                        //clearLookObj.SetActive(true);
                    }
                    if (clearLook && swipeScript.GetNowIndex() == SwipeScript.DIRECT.CENTER)
                    {
                        clearLookObj.SetActive(false);
                        gameManager.stopMove = false;
                        fase = FASE.END;
                    }
                    break;

                case FASE.LIGHT_POWER:

                    break;
                case FASE.PRAY:
                    if (touchScript.IsPray())
                    {
                        prayTimer += Time.deltaTime;

                        //chappy.SetActive(false);
                    }
                    //一定時間祈り続けたら
                    if (!prayOK &&prayTimer > 2.0f)
                    {
                        Singleton<SoundManagerScript>.instance.PlaySE("se_tutorial", gameObject);
                        gameManager.stopMove = false;
                        clearPray = true;
                        clearPrayObj.SetActive(true);
                        prayOK = true;
                    }
                    break;
                case FASE.END:

                    break;
            }

        }
    }
}
