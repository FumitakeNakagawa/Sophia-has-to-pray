﻿using System.Collections;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.UI;

namespace Tutorial
{
    public class FadeScript : MonoBehaviour
    {
        Color Color;

        [SerializeField]
        TouchScript touchSprict;

        [SerializeField]
        GameManager_TutorialScript GameManagerScript;

        float Alpha;
        [SerializeField, Range(1.0f, 255.0f), Header("フェードする速さ(小さいほど長い)")]
        float fadeSpeed;

        [SerializeField, Range(1.0f, 180.0f), Header("フェード開始までの時間")]
        float timer;

        Image image;


        bool FadeEnd;

        [SerializeField]
        float startFadeSpeed;

        bool startFadeEnd;
        public bool IsStartFadeEnd() { return startFadeEnd; }
        // Use this for initialization
        void Start()
        {
            Color = new Color(0, 0, 0, 1);
            FadeEnd = false;

            startFadeEnd = false;
            image = GetComponent<Image>();
        }

        // Update is called once per frame
        void Update()
        {
            if(GameManagerScript.GetState() == GameManager_TutorialScript.STATE.STANDBY)
            {
                Color.a -= startFadeSpeed * Time.deltaTime;
                Color.a = Mathf.Max(0.0f, Color.a);
                if (Color.a <= 0)
                    startFadeEnd = true;
            }
            else if (GameManagerScript.GetState() == GameManager_TutorialScript.STATE.PLAY)
            {
                if (touchSprict)
                {
                    //祈ってる間
                    if (touchSprict.IsPray())
                        Color.a = 0.8f;
                    else
                        Color.a = 0.0f;

                }
            }

            //クリア時ホワイトアウト
            else if (GameManagerScript.GetState() == GameManager_TutorialScript.STATE.CLEAR)
            {
                Alpha += fadeSpeed * Time.deltaTime; ;
                Color = new Vector4(1, 1, 1, Alpha);
            }

            //ゲームオーバー時ブラックアウト
            else if (GameManagerScript.GetState() == GameManager_TutorialScript.STATE.GAME_OVER)
            {
                timer -= Time.deltaTime;
                if (timer <= 0)
                {
                    Alpha += fadeSpeed * Time.deltaTime; ;
                    Color = new Color(0, 0, 0, Alpha);
                }
            }

            //フェードの終了合図
            if (Alpha > 1.0f)
            {
                Alpha = 1.0f;
                Color.a = Alpha;
                FadeEnd = true;
            }

            image.color = Color;
        }

        public bool IsFadeEnd() { return FadeEnd; }
    }
}