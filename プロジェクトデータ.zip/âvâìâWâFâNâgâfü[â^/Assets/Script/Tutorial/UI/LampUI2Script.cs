﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Tutorial
{
    public class LampUI2Script : MonoBehaviour
    {

        Image image;//Imageコンポーネント

        [SerializeField]
        Sprite[] sprites;//画像データ

        [SerializeField]
        LightScript lightScript;//ライトスクリプト

        [SerializeField, Header("デバッグ用の%表示")]
        float Debug;

        int Cut;//分割数


        [SerializeField]
        bool UseVibrate, UseSE;//SE,振動使用するか

        const float Percentage = 100.0f;

        [SerializeField]
        float[] ArrayPercentage;
        bool[] Changed;

        [SerializeField]
        float timer;

        bool flash_flg;
        // Use this for initialization
        void Start()
        {
            flash_flg = false;

            image = GetComponent<Image>();
            int arraySize = sprites.Length;

            //要素ごとのパーセンテージ
            ArrayPercentage = new float[arraySize];

            Changed = new bool[arraySize];
            Changed[0] = true;
            float per = (float)Percentage / (arraySize - 1);
            for (int i = 0; i < ArrayPercentage.Length; i++)
            {
                ArrayPercentage[i] = 100 - (i * per);
            }
        }

        // Update is called once per frame
        void Update()
        {
            float percentage = lightScript.Percentage();
            Debug = percentage;
            for (int i = 0; i < ArrayPercentage.Length; i++)
            {
                if (Changed[i]) continue;
                if (percentage <= ArrayPercentage[i])
                {

                    Changed[i] = true;
                    flash_flg = true;
                    image.sprite = sprites[i];

                    if (UseVibrate) Vibrate();
                    if (UseSE) PlaySE();

                    StartCoroutine(WaitForReset(timer));
                }
            }
           if(flash_flg) Flash();
        }


        //振動する
        void Vibrate()
        {
            Handheld.Vibrate();
        }


        //SE再生
        void PlaySE()
        {
            Singleton<SoundManagerScript>.instance.PlaySE("se_fire", gameObject);

        }

        //点滅
        IEnumerator FlashCoroutine(float interval)
        {
            yield return new WaitForSeconds(interval);
            //反転(点滅)
            image.enabled = !image.enabled;
        }

        void Flash()
        {
            image.enabled = !image.enabled;
        }


        IEnumerator WaitForReset(float waitSeconds)
        {
            yield return new WaitForSeconds(waitSeconds);
            image.enabled = true;
            flash_flg = false;
        }
    }


}