﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Tutorial
{
    public class WhatIsPinch : MonoBehaviour
    {
        [SerializeField]
        GameObject next;

        TutorialManagerScript TutorialManager;

        [SerializeField]
        GameManager_TutorialScript gameManager;

        [SerializeField]
        GameObject[] children;

        // Use this for initialization
        void Start()
        {
            TutorialManager = gameObject.transform.root.GetComponent<TutorialManagerScript>();
            children = new GameObject[gameObject.transform.childCount];

            for (int index = 0; index < children.Length; index++)
            {
                children[index] = gameObject.transform.GetChild(index).gameObject;
                children[index].SetActive(false);
            }

        }

        // Update is called once per frame
        void Update()
        {
            TutorialManager.GetEnemy(0).enemy2Script.enabled = true;
            TutorialManager.GetEnemy(1).enemy2Script.enabled = true;
            TutorialManager.GetEnemy(2).enemy2Script.enabled = true;

            gameManager.stopMove = false;
            if(TutorialManager.GetPinchScript().GetPinchIndex()>=0)
            {
                gameManager.stopMove = true;
                foreach (var it in children)
                    it.SetActive(true);
                TutorialManager.GetEnemy(0).enemy2Script.enabled = false;
                TutorialManager.GetEnemy(1).enemy2Script.enabled = false;
                TutorialManager.GetEnemy(2).enemy2Script.enabled = false;
            }
        }


        public void Next()
        {
            foreach (var it in children)
                it.SetActive(false);
            next.SetActive(true);
            gameObject.SetActive(false);
        }
    }
}
