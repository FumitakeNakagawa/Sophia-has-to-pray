﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Tutorial
{
	public class MoveStageScript : MonoBehaviour
	{
		[SerializeField]
		GameManager_TutorialScript GameManagerScript;

		[SerializeField]
		TouchScript touchScript;

		[SerializeField]
		float speed;

        [SerializeField]
        GameObject obj;
		void Update()
		{
            if (obj.activeInHierarchy) return;
			if(GameManagerScript.GetState()== GameManager_TutorialScript.STATE.PLAY)
			{
				if (!touchScript.IsPray())
				{
					transform.Translate(0, 0, -speed * Time.deltaTime);

					if (transform.position.z < -40)
					{
						transform.Translate(0, 0, 80);
					}
				}
			}
		}
	}
}
