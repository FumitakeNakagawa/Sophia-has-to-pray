﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Tutorial
{
    public class Enemy2Script : MonoBehaviour
    {
        public int[] pattern;
        public int patternIndex;
        public StateScript stateScript;
        public StateScript.State state;
        public GameObject gameManager;
        public GameObject player;
        public float speed;
        public float viewAngle;             //視野角
        public float viewDistance;          //視野範囲
        public Light pointLight;            //プレイヤーのポイントライト
		public Light spotLight;				//エネミーのスポットライト
		public int countFeint;              //連続でフェイントした回数
        public int fallForFeint;            //フェイントにひっかかった回数
        public int countGhost;
        public float timeBreath;

        [SerializeField, Header("死んだ時の敵の距離")]
        float deadDist;
        public float GetDeadDist() { return deadDist; }
        EnemyAnimatorScript animator;
       public EnemyAnimatorScript GetAnimatorScript() { return animator; }

        bool GameOverFlg;
        public bool isGameOver() { return GameOverFlg; }
        public void SetGameOver(bool val) { GameOverFlg = val; }
        // Use this for initialization
        void Start()
        {
            animator = GetComponent<EnemyAnimatorScript>();
            state = stateScript.state;
            //state = new EnemyStateScript.StateNotFind();
            state.Enter(gameObject);
        }

        // Update is called once per frame
        void Update()
        {

            StateScript.State next = state.Update(gameObject);
            //print(state);
            //次のステートへ切り替える
            if (next != null)
            {
                ChangeState(next);
            }

            //Teleportation();
        }

        //ステート切り替え
        public void ChangeState(StateScript.State state)
        {
            if (this.state.getState() != null) this.state.Init(gameObject);
            this.state.Exit(gameObject);
            this.state = state;
            this.state.Enter(gameObject);
        }

        //メッセージ
        public IEnumerator Message(string mes, float delay = 0.0f)
        {
            yield return new WaitForSeconds(delay);

            state.Message(mes);
        }

        //プレイヤーが隠れきったら瞬間移動
        public void Teleportation()
        {
            Vector3 dist = player.transform.position - transform.position;
            Vector3 dir = new Vector3(Mathf.Sin(transform.localEulerAngles.y * Mathf.PI / 180.0f), 0.0f, Mathf.Cos(transform.localEulerAngles.y * Mathf.PI / 180.0f));

            if (dist.magnitude > 15.0f && Vector3.Dot(dir.normalized, Vector3.forward) < 0.0f && Vector3.Dot(dir.normalized, dist.normalized) < 0.0f)
            {
                Vector3 pos = new Vector3(0.0f, 0.0f, 25.0f);
                switch (Random.Range(1, 4))
                {
                    case 2:
                        pos.x = -5.0f;
                        break;
                    case 3:
                        pos.x = 5.0f;
                        break;
                }
                transform.position = player.transform.position + pos;
                countGhost = 0;
            }
        }
    }
}
