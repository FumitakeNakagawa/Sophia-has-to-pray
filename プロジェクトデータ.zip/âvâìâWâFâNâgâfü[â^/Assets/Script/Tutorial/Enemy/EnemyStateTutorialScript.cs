﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using main;

public class EnemyStateTutorialScript : StateScript
{
	public Light spotLight;
	public Shader standard;
	public Shader Ghost;
    public float speed;

	public GameObject Breath;

	//public StateScript.State state;
	void Start()
	{
		//state.SetEnemyAnimatorScript(GetComponent<EnemyAnimatorScript>());
		print("start");
		state = new StateNotFind();
		//state = new StateToHaveFace();
	}

	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//見つけていない状態
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
	public class StateNotFind : StateScript.State
	{
		float viewAngle;
		float viewDist;
		int countGhost;
		int rand;
		const float viewDistPlayer = 16.0f;
		bool teleportFg;
		const float timeToTeleport = 4.0f;
		float time;
		float deltaTime;

		public override void Enter(GameObject enemy)
		{
			GameManagerScript gms = enemy.GetComponent<Enemy2Script>().gameManager.GetComponent<GameManagerScript>();
			if (gms.GetState() == GameManagerScript.STATE.PLAY)
			{
				enemy.GetComponent<EnemyStateTutorialScript>().spotLight.enabled = false;
			}
			player = enemy.GetComponent<Enemy2Script>().player;
			state = new StateNotFindMove();
			//state = new StateNotFindLookAround();
			state.Enter(enemy);
			viewAngle = enemy.GetComponent<Enemy2Script>().viewAngle;
			viewDist = enemy.GetComponent<Enemy2Script>().viewDistance;
			countGhost = enemy.GetComponent<Enemy2Script>().countGhost;

			if (player.GetComponent<TouchScript>().IsPray() == false)
			{
				rand = Random.Range(0, 99);

				time = Time.time;
				if (Random.Range(1, 20) <= 1)
				{
					teleportFg = true;
				}
			}
			else
			{
				rand = 100;
			}
		}
		public override StateScript.State DecisionMaking(GameObject enemy)
		{
			Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;

			if (hideFg == false)
			{
				Vector3 dir = new Vector3(Mathf.Sin(enemy.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.transform.localEulerAngles.y * 0.01745f));

				//見つけた状態へ
				if (Vector3.Distance(posPlayer, enemy.transform.position) < viewDist && Vector3.Dot(dir.normalized, (posPlayer - enemy.transform.position).normalized) > Mathf.Cos(viewAngle * 0.01745f))
				{
					print("見つけた状態へ");
					//BlendingTimer = 0.0f;
					return new StateFind();
				}
			}
			else
			{
				hideFg = false;
			}

			return null;
		}
		public override void Method(GameObject enemy)
		{
			Vector3 dist = player.transform.position - enemy.transform.position;
			Vector3 dir = new Vector3(Mathf.Sin(enemy.transform.localEulerAngles.y * Mathf.PI / 180.0f), 0.0f, Mathf.Cos(enemy.transform.localEulerAngles.y * Mathf.PI / 180.0f));

			if (dist.magnitude > 15.0f && Vector3.Dot(dir.normalized, Vector3.forward) < 0.0f && Vector3.Dot(dir.normalized, dist.normalized) < 0.0f)
			{
				Vector3 pos = new Vector3(0.0f, 0.0f, 25.0f);
				switch (Random.Range(1, 4))
				{
					case 2:
						pos.x = -5.0f;
						break;
					case 3:
						pos.x = 5.0f;
						break;
				}
				enemy.transform.position = player.transform.position + pos;
				countGhost = 0;
			}
		}
	}

	//移動
	public class StateNotFindMove : StateNotFind
	{
		float speed;
		bool soundFg;           //音が聞こえたかの
		Vector3 posListen;
		Vector3 posPast;        //移動し始める前の座標
		const float distWalk = 10.0f;

		public override void Enter(GameObject enemy)
		{
			timeBreath = Time.time;
			speed = enemy.GetComponent<EnemyStateTutorialScript>().speed;
			posPast = enemy.transform.position;
			enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, 180.0f, enemy.transform.localEulerAngles.z);
		}
		public override StateScript.State DecisionMaking(GameObject enemy)
		{
			//一定移動したら
			if (Vector3.Distance(posPast, enemy.transform.position) > distWalk)
			{
				return new StateNotFindLookAround();
			}
			return null;
		}
		public override void Method(GameObject enemy)
		{
			enemy.transform.position += Vector3.back * speed * Time.deltaTime;

		}
	}

	//見渡す
	class StateNotFindLookAround : StateNotFind
	{
		int count;
		const int timeLookAround = 120;
		public override void Enter(GameObject enemy) { }
		public override State DecisionMaking(GameObject enemy)
		{
			if (count > timeLookAround)
			{
				return new StateNotFindMove();
				//return new StateNotFindMove2();
			}
			return null;
		}
		public override void Method(GameObject enemy)
		{
			if (count < timeLookAround * 0.25 || count > timeLookAround * 0.75) enemy.transform.Rotate(new Vector3(0.0f, 90.0f / timeLookAround, 0.0f));
			else enemy.transform.Rotate(new Vector3(0.0f, -90.0f / timeLookAround, 0.0f));
			count++;

		}
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//見つけた状態
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
	protected class StateFind : StateScript.State
	{
		public override void Enter(GameObject enemy)
		{
			state = new StateFindMove();
			state.Enter(enemy);
		}
		public override State DecisionMaking(GameObject enemy)
		{
			//find = true;

			//GetEnemyAnimatorScript().SetFind(true);
			//BlendingTimer += 0.25f * Time.deltaTime;
			//GetEnemyAnimatorScript().SetBlend(BlendingTimer);
			if (hideFg == false)
			{
				//近づいたら
				////近づいたら
				Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;

				Vector3 v = enemy.transform.position - enemy.GetComponent<Enemy2Script>().player.transform.position;
				Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
				if (Vector3.Distance(posPlayer, enemy.transform.position) < 3.0f)
				{
					if (Vector3.Dot(v.normalized, dirPlayer.normalized) > 0.86f)
					{
						print("追いついた状態へ");
						return new StateStuckUp();
					}
					else
					{
						print("顔をひょっこり出す");
						return new StateToHaveFace();
					}
				}
			}
			else
			{
				hideFg = false;
			}

			return null;
		}
	}

	//移動
	class StateFindMove : StateFind
	{
		private float speed;
		public override void Enter(GameObject enemy)
		{
			speed = enemy.GetComponent<EnemyStateTutorialScript>().speed * 2.0f;

			//プレイヤーの方へ向く
			Vector3 v = enemy.GetComponent<Enemy2Script>().player.transform.position - enemy.transform.position;
			float rad = Mathf.Acos(Vector3.Dot(v.normalized, Vector3.forward));
			if (Vector3.Cross(v.normalized, Vector3.forward).y > 0.0f) rad = -rad;
			enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, rad * 180.0f / Mathf.PI, enemy.transform.localEulerAngles.z);
			float angle = TargetToFace(enemy.transform.position, enemy.GetComponent<Enemy2Script>().player.transform.position);
			enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, angle, enemy.transform.localEulerAngles.z);
		}
		public override State DecisionMaking(GameObject enemy)
		{
			if (hideFg)
			{
				print("見失う");
				//return new StateFindNotFind();
				enemy.GetComponent<Enemy2Script>().ChangeState(new StateWalk(4.0f));
			}
			return null;
		}
		public override void Method(GameObject enemy)
		{
			//移動
			Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
			Vector3 v = new Vector3(posPlayer.x - enemy.transform.position.x, 0.0f, posPlayer.z - enemy.transform.position.z);
			v.Normalize();
			enemy.transform.position += v * speed * Time.deltaTime;

		}
	}

	//顔をひょっこり出す
	class StateToHaveFace : State
	{
		const float time = 5.0f;          //顔出してからGAMEOVERまでの時間
		float timeGameOver;
		public override void Enter(GameObject enemy)
		{
			state = null;
			timeGameOver = Time.time + time;
			player = enemy.GetComponent<Enemy2Script>().player;
		}
		public override State DecisionMaking(GameObject enemy)
		{
			if (Time.time >= timeGameOver)
			{
				print("捕まえた");
				enemy.GetComponent<Enemy2Script>().ChangeState(new StateStuckUp());
			}
			else if (hideFg)
			{
				print("探す");
				enemy.GetComponent<Enemy2Script>().ChangeState(new StateWalk(8.0f));
			}
			else
			{
				hideFg = false;
			}
			return null;
		}
		public override void Method(GameObject enemy)
		{
			//プレイヤーの横にひょっこり顔を出す
			Vector3 playerAngle = -enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles;
			enemy.transform.position = new Vector3(player.transform.position.x, 0.0f, player.transform.position.z) + new Vector3(Mathf.Sin(playerAngle.y * 0.01745f) * -3.4f + Mathf.Cos(playerAngle.y * 0.01745f) * -1.2f, 0.0f, Mathf.Cos(playerAngle.y * 0.01745f) * 3.4f - Mathf.Sin(playerAngle.y * 0.01745f) * 1.2f);
			float angle = TargetToFace(enemy.transform.position, enemy.GetComponent<Enemy2Script>().player.transform.position);
			enemy.transform.localEulerAngles = new Vector3(0.0f, angle, 45.0f);
		}
		public override void Exit(GameObject enemy)
		{
			enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, enemy.transform.localEulerAngles.y, 0.0f);
		}
	}
	//一周歩く
	public class StateWalk : State
	{
		protected float time;
		protected float speed;
		float timeToNotFind;
		float rand;

		public StateWalk(float time)
		{
			timeToNotFind = time;
		}
		public override void Enter(GameObject enemy)
		{
			base.Enter(enemy);
			hideFg = true;
			time = Time.time;
			speed = enemy.GetComponent<EnemyStateTutorialScript>().speed;
			state = null;
		}
		public override State DecisionMaking(GameObject enemy)
		{
			if (hideFg == false)
			{
				////近づいたら
				Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
				//if (Vector3.Distance(posPlayer, enemy.transform.position) < 3.0f)
				//{
				//    //print("追いついた状態へ");
				//    return new StateStuckUp();
				//}

				Vector3 v = enemy.transform.position - enemy.GetComponent<Enemy2Script>().player.transform.position;
				Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
				//if (Vector3.Distance(posPlayer, enemy.transform.position) < 3.0f && Vector3.Dot(v.normalized, dirPlayer.normalized) > 0.707f)
				{
					print("見つけた状態へ");
					return new StateFind();
				}
			}
			else
			{
				hideFg = false;
			}

			//一周してもみつからなかったら完全に見失う
			if (Time.time >= time + timeToNotFind)
			{
				//if (Random.Range(0, 3) == 1)
				//{
				//    print("引き返す");
				//    return new StateTurnBack();
				//}
				//else
				{
					//print("完全に見失う");
					//return new StateNotFind();
					print("見失う");
					return new StateLeave();
				}
			}

			//フェイントへ
			//if (enemy.GetComponent<Enemy2Script>().countFeint < 1)
			{
				//if (Time.time >= time + 1.0f)
				if (Random.Range(1, (int)(1024 * Mathf.Pow(2, enemy.GetComponent<Enemy2Script>().countFeint))) == 1)
				{
					//print("フェイントへ");
					//return new StateFeint();
				}
			}

			return null;
		}
		public override void Method(GameObject enemy)
		{
			//一週歩く
			Vector3 dir = new Vector3(Mathf.Sin(enemy.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.transform.localEulerAngles.y * 0.01745f));
			enemy.transform.position = enemy.transform.position + dir * 0.01f * Time.deltaTime;
			enemy.transform.localEulerAngles += new Vector3(0.0f, 360.0f / timeToNotFind / 60.0f, 0.0f);

		}
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//フェイント
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
	public class StateFeint : State
	{
		bool timeSetFg;
		float timeAppear = 0.0f;
		protected const float TimeGameOver = 3.0f;            //隠れているのをやめてからGame Overになるまでの時間(s)
		protected const float TimeFeint = 2.0f;               //フェイントの最低時間(s)
		float timeFeint;
		float timeGameOverLower;                    //Game Overになるまでの時間を減らす
		public override void Enter(GameObject enemy)
		{
			print("1");
			hideFg = true;
			float t = TimeFeint + Random.Range(0.0f, 4.0f);
			timeFeint = Time.time + t;
			timeGameOverLower = 0.25f - Mathf.Pow(0.5f, 0.5f + (float)enemy.GetComponent<Enemy2Script>().fallForFeint * 0.1f);
			state = new StateFaintWait();
			state.Enter(enemy);
			enemy.GetComponent<Enemy2Script>().countFeint++;
			enemy.GetComponent<Enemy2Script>().fallForFeint++;
			//足音をミュートにする
			//enemy.GetComponent<AudioSource>().mute = true;
		}
		public override State DecisionMaking(GameObject enemy)
		{
			if (timeSetFg)
			{
				if (Time.time >= timeAppear)
				{
					print("捕まえた");
					return new StateStuckUp();
				}
			}
			else
			{
				if (Time.time >= timeFeint)
				{
					print("見失った");
					//return new StateNotFind();
					return new StateLeave();
				}
			}
			return null;
		}
		public override void Method(GameObject enemy)
		{
			if (hideFg == false)
			{
				if (timeSetFg == false)
				{
					timeSetFg = true;
					timeAppear = TimeGameOver + Time.time + timeGameOverLower;
				}
			}
			else
			{
				timeSetFg = false;
				hideFg = false;
			}
		}
		public override void Exit(GameObject enemy)
		{
			//ミュート解除
			//enemy.GetComponent<AudioSource>().mute = false;
		}
	}
	//待機
	public class StateFaintWait : StateFeint
	{
		public override void Enter(GameObject enemy)
		{
			hideFg = true;
		}
		public override State DecisionMaking(GameObject enemy)
		{
			if (hideFg == false)
			{
				print("移動");
				return new StateFaintMove();
			}
			else hideFg = false;

			return null;
		}
		public override void Method(GameObject enemy)
		{

		}
	}
	//プレイヤーにあわせて移動
	public class StateFaintMove : StateFeint
	{
		Vector3 dirPlayer;
		public override void Enter(GameObject enemy)
		{
			dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
		}
		public override State DecisionMaking(GameObject enemy)
		{
			if (hideFg)
			{
				print("探す");
				enemy.GetComponent<Enemy2Script>().ChangeState(new StateWalk(5.0f));
			}

			return null;
		}
		public override void Method(GameObject enemy)
		{
			enemy.transform.position = new Vector3(enemy.GetComponent<Enemy2Script>().player.transform.position.x, 0.0f, enemy.GetComponent<Enemy2Script>().player.transform.position.z) + dirPlayer.normalized * 3.0f;
			float rad = TargetToFace(enemy.transform.position, enemy.GetComponent<Enemy2Script>().player.transform.position);
			enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, rad, enemy.transform.localEulerAngles.z);
		}
	}

	//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//追いついた状態
	//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	public class StateStuckUp : StateScript.State
	{
		public override void Enter(GameObject enemy)
		{
			state = new StateStuckUpWait();
			state.Enter(enemy);
		}
		public override State DecisionMaking(GameObject enemy)
		{
			return null;
		}
	}

	//待機
	public class StateStuckUpWait : StateStuckUp
	{
		public override void Enter(GameObject enemy)
		{
			print("生成されました");
		}
		public override State DecisionMaking(GameObject enemy)
		{

			if (hideFg == false)
			{
				Vector3 v = enemy.transform.position - enemy.GetComponent<Enemy2Script>().player.transform.position;
				Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
				print(Vector3.Dot(v.normalized, dirPlayer.normalized));
				if (Vector3.Dot(v.normalized, dirPlayer.normalized) > 0.707f)
				{
					print("GAME OVERへ");

					return new StateStuckGameOver();
				}
			}
			else
			{
				hideFg = false;
			}
			return null;
		}
		public override void Method(GameObject enemy)
		{
			//if(hideFg)
			{
				//位置をプレイヤーの目の前へ
				Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
				Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
				enemy.transform.position = new Vector3(posPlayer.x, 0.0f, posPlayer.z) + dirPlayer.normalized * 3.0f;
				//プレイヤーの方へ向く
				Vector3 v = posPlayer - enemy.transform.position;
				float rad = Mathf.Acos(Vector3.Dot(v.normalized, Vector3.forward));
				if (Vector3.Cross(v.normalized, Vector3.forward).y > 0.0f) rad = -rad;
				enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, rad * 180.0f / Mathf.PI, enemy.transform.localEulerAngles.z);
				float angle = TargetToFace(enemy.transform.position, posPlayer);
				enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, angle, enemy.transform.localEulerAngles.z);
			}
		}
	}

	//GAMEOVER
	public class StateStuckGameOver : StateStuckUp
	{
		Vector3 pos;

		public override void Enter(GameObject enemy)
		{
			GameManagerScript gms = enemy.GetComponent<Enemy2Script>().gameManager.GetComponent<GameManagerScript>();
			if (gms.GetState() == GameManagerScript.STATE.PLAY)
			{
				Singleton<SoundManagerScript>.instance.PlaySE("se_shout", gms.gameObject);
				foreach (Transform child in enemy.transform)
				{
					child.gameObject.layer = LayerMask.NameToLayer("Water");
				}
				enemy.GetComponent<EnemyStateTutorialScript>().spotLight.enabled = true;
				enemy.GetComponent<Enemy2Script>().pointLight.enabled = false;
				pos = (enemy.GetComponent<Enemy2Script>().player.transform.position - enemy.transform.position).normalized;
				enemy.transform.position += pos + Vector3.down * 0.8f;
				enemy.transform.localScale += Vector3.one * 2;
				gms.SetState(GameManagerScript.STATE.GAME_OVER);
				//GetEnemyAnimatorScript().TriggerGameOverFlg();

			}
		}
		public override State DecisionMaking(GameObject enemy)
		{
			return null;
		}
		public override void Method(GameObject enemy)
		{

		}
	}

	//*************************************************************************************************************************************************
	//
	//*************************************************************************************************************************************************
	//過ぎ去っていく
	class StateLeave : StateScript.State
	{
		float speed;
		const float distWalk = 10.0f;
		int rand;
		float time;
		float timeChangeState;  //次のステートに切り替える時間
		Enemy2Script script;
		int pattern;
		float viewDist;
		float viewAngle;

		public override void Enter(GameObject enemy)
		{
			player = enemy.GetComponent<Enemy2Script>().player;
			timeBreath = Time.time;
			speed = enemy.GetComponent<EnemyStateTutorialScript>().speed;
			enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, 180.0f, enemy.transform.localEulerAngles.z);
			time = Time.time;
			script = enemy.GetComponent<Enemy2Script>();
			//if (script.patternIndex < script.pattern.Length) pattern = script.pattern[script.patternIndex];
			//else pattern = Random.Range(1, 1);
			pattern = Random.Range(1, 1);
			switch (pattern)
			{
				case 1:
					timeChangeState = 5.0f;
					break;
				case 2:
					timeChangeState = 0.0f;
					break;
				case 3:
					timeChangeState = 15.0f;
					break;
			}
			viewAngle = enemy.GetComponent<Enemy2Script>().viewAngle;
			viewDist = enemy.GetComponent<Enemy2Script>().viewDistance;
		}
		public override StateScript.State DecisionMaking(GameObject enemy)
		{
			switch (pattern)
			{
				case 1:
					print(Time.time + " : " + (time + timeChangeState));
					if (Time.time >= time + timeChangeState)
					{
						Vector3 pos = new Vector3(0.0f, 0.0f, 25.0f);
						switch (Random.Range(1, 4))
						{
							case 2:
								pos.x = -5.0f;
								break;
							case 3:
								pos.x = 5.0f;
								break;
						}
						enemy.transform.position = player.transform.position + pos;
						return new StateNotFind();
					}
					break;
				case 2:
					print(Time.time + " : " + (time + timeChangeState));
					if (hideFg == false)
					{
						//return new StateAppear();
					}
					else
					{
						hideFg = false;
					}
					break;
				case 3:
					print(Time.time + " : " + (time + timeChangeState));
					print(script.patternIndex);
					if (Time.time >= time + timeChangeState)
					{
						//find = false;

						//return new StateToHaveFace();
					}
					break;
			}

			Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;

			if (hideFg == false)
			{
				Vector3 dir = new Vector3(Mathf.Sin(enemy.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.transform.localEulerAngles.y * 0.01745f));

				//見つけた状態へ
				if (Vector3.Distance(posPlayer, enemy.transform.position) < viewDist && Vector3.Dot(dir.normalized, (posPlayer - enemy.transform.position).normalized) > Mathf.Cos(viewAngle * 0.01745f))
				{
					print("見つけた状態へ");
					return new StateFind();
				}
			}
			else
			{
				hideFg = false;
			}

			return null;
		}
		public override void Method(GameObject enemy)
		{
			enemy.transform.position += Vector3.back * speed * Time.deltaTime;

		}
		public override void Exit(GameObject enemy)
		{
			script.patternIndex++;
		}
	}
}