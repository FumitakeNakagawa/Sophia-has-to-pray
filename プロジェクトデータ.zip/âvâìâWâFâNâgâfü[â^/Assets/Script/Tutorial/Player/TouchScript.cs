﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Tutorial
{
    public class TouchScript : MonoBehaviour
    {
        [SerializeField]
        GameObject enemyParent;

        [SerializeField]
        GameObject[] enemies;

        [SerializeField]
        GameObject GameManager;

        [SerializeField]
        GameObject pray;

        PluginScript plugin;

        GameManager_TutorialScript GameManagerScript;

        [SerializeField]
        bool isPray;

        [SerializeField]
        TutorialManagerScript TutorialManager;

        SwipeScript swipeScript;

        void Start()
        {
            isPray = false;

            plugin = GameManager.GetComponent<PluginScript>();
            GameManagerScript = GameManager.GetComponent<GameManager_TutorialScript>();
            swipeScript = GetComponent<SwipeScript>();

            int size = 0;
            while (true)
            {
                if (enemyParent.transform.Find(size.ToString()))
                    size++;
                else
                    break;
            }
            enemies = new GameObject[size];

            for (int index = 0; index < size; index++)
                enemies[index] = enemyParent.transform.Find(index.ToString()).gameObject;
        }

        void Update()
        {
            if (!TutorialManager.GetPray()) return;
            //プレイ中
            if (GameManagerScript.GetState() == GameManager_TutorialScript.STATE.PLAY)
            {
                if (swipeScript.t > 0 && swipeScript.t < 1) return;
                //祈ったら
                if (plugin.proximityValue == 0 || Input.touchCount > 1 || Input.GetKey(KeyCode.Space))
                {
                    if (!isPray)
                    {
                        isPray = true;
                        Singleton<SoundManagerScript>.instance.PlaySE("se_pray", pray);
                    }
                }
                else
                {
                    isPray = false;
                }

                if (isPray)
                    foreach (var it in enemies)
                        StartCoroutine(it.GetComponent<Enemy2Script>().Message("hide"));

            }
            else enabled = false;
        }

        /*祈っているか*/
        public bool IsPray() { return isPray; }
    }
}