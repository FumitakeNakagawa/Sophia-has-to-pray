﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Tutorial
{
    public class SwipeScript : MonoBehaviour
    {

        enum STATE
        {
            START,
            CONITNUE,
            END,
        };
        STATE state;

        public enum DIRECT : int
        {
            LEFT,
            CENTER,
            RIGHT,
            DOWN,

            DIRECT_MAX,
        }

        [SerializeField]
        LightPowerScript LPS;

        [SerializeField, Header("回転角")]
        [Header("0:左 1:真中 2:右 3:後")]
        Vector3[] offsetAngle = new Vector3[(int)DIRECT.DIRECT_MAX];

        [SerializeField]
        Quaternion[] offset;

        [SerializeField]
        float speed;

        [SerializeField]
        GameObject Swipe;

        //タッチ開始位置･終端位置
        Vector2 TouchStart, TouchEnd;

        //スワイプ(フリック)の長さ
        float length;

        //Slerpのt
        public float t;

        //今の向いている方向のオフセットのインデックス
        public DIRECT nowIndex;
        //次に向く方向のオフセットのインデックス
        public DIRECT nextIndex;
        //後ろ向いたときの前方向のインデックス
        DIRECT frontIndex;

        public DIRECT GetNowIndex() { return nowIndex; }
        //Slerp中か
        public bool slerp;
        //後ろ向いているときか
        bool backCam;

        //ダブルタップされたか
        bool doubleTap;

        Quaternion rotation;
        Quaternion frontCam;

        GyroSensorScript gyroScript;
        [SerializeField]
        SliderScript slider;

        [SerializeField]
        UIArea UIArea;

        TouchScript touchScript;

        [SerializeField]
        GameManager_TutorialScript GameManagerScript;

        [SerializeField]
        TutorialManagerScript TutorialManager;
        bool TouchUI;

        public void SetNextIndex(DIRECT index) { nextIndex = index; }
        // Use this for initialization
        void Start()
        {

            slerp = false;
            state = STATE.START;
            nextIndex = nowIndex = DIRECT.CENTER;
            
            //オフセットクォータニオン生成
            offset = new Quaternion[offsetAngle.Length];
            for (int index = 0; index < offset.Length; index++)
            {
                Vector3 v = offsetAngle[index];
                offset[index] = Quaternion.Euler(v.x, v.y, v.z);
            }

            rotation = new Quaternion(0, 0, 0, 1);
            backCam = false;
            doubleTap = false;
            frontCam = transform.rotation;
            t = 1;

            gyroScript = GetComponent<GyroSensorScript>();
            touchScript = GetComponent<TouchScript>();
            GameManagerScript = GetComponent<PlayerScript>().GetGameManager();

            TouchUI = false;
        }

        string str;
        // Update is called once per frame
        void Update()
        {
            //チュートリアルのスワイプ機能が有効化しているか
            if (!TutorialManager.GetSwipeOn())
                return;


            Vector2 v = new Vector2(0, 0);


            if (!slerp)
            {
                if (touchScript.IsPray()) return;

                //スワイプ
                switch (state)
                {
                    //タッチ開始
                    case STATE.START:
                        doubleTap = false;
                        if (Input.touchCount == 1)
                        {
                            TouchStart = Input.GetTouch(0).position;
                            state = STATE.CONITNUE;
                        }
                        break;
                   　//タッチ継続中
                    case STATE.CONITNUE:
                        if (UIArea.Pressed) TouchUI = true;
                        if (slider.Pressed) TouchUI = true;

                        if (Input.touchCount <= 0)
                            state = STATE.END;
                        else
                            TouchEnd = Input.GetTouch(0).position;
                        break;
                    //タッチ終了
                    case STATE.END:
                        if (TouchUI)
                            TouchStart = TouchEnd = Vector2.zero;
                        //スワイプ方向ベクトル・長さ取得
                        v = TouchEnd - TouchStart;
                        length = Vector2.Distance(TouchEnd, TouchStart);
                        state = STATE.START;
                        slerp = true;
                        TouchUI = false;

                        break;
                }


            }
            //左スワイプで右へ向く
            if (v.x < 0 && length > 200f)
            {
                if (nowIndex == DIRECT.RIGHT || nowIndex == DIRECT.DOWN) return;
                nextIndex = nowIndex + 1;
                t = 0.0f;
                Singleton<SoundManagerScript>.instance.PlaySE("se_swipe", Swipe);
            }
            //右スワイプで左向く
            else if (v.x > 0 && length > 200f)
            {
                if (nowIndex == DIRECT.LEFT || nowIndex == DIRECT.DOWN) return;
                nextIndex = nowIndex - 1;
                t = 0.0f;
                Singleton<SoundManagerScript>.instance.PlaySE("se_swipe", Swipe);
            }

            //if (Input.GetKeyDown(KeyCode.LeftArrow))
            //{
            //    nextIndex = DIRECT.LEFT;
            //    t = 0.0f;
            //}
            //else if (Input.GetKeyDown(KeyCode.RightArrow))
            //{
            //    nextIndex = DIRECT.RIGHT;
            //    t = 0.0f;
            //}
            //else if (Input.GetKeyDown(KeyCode.UpArrow))
            //{
            //    nextIndex = DIRECT.CENTER;
            //    t = 0.0f;
            //}
            //if (Input.GetKeyDown(KeyCode.DownArrow))
            //{
            //    nextIndex = DIRECT.DOWN;
            //    t = 0.0f;
            //}

            //方向転換完了
            if (slerp && t >= 1.0f)
            {
                t = 1f;
                nowIndex = nextIndex;
                slerp = false;
            }

            //フレーム間方向転換距離
            float frame = speed * Time.deltaTime;
            t += frame;

            Quaternion q1;
            Quaternion q2;
            //現在の向き角度と次に向く予定の方向角度取得
            q1 = offset[(int)nowIndex];
            q2 = offset[(int)nextIndex];

            t = Mathf.Min(1.0f, t);

            //回転
            rotation = Quaternion.Slerp(q1, q2, t);
            str = "now:" + nowIndex.ToString() + "next:" + nextIndex.ToString();

        }

        private void OnGUI()
        {
            GUIStyle style = new GUIStyle();
            style.fontSize = 40;
            style.normal.textColor = Color.white;
            //GUI.Label(new Rect(0, 300, 100, 100), str, style);
        }

        public Quaternion GetRotation() { return rotation; }
        public bool IsBackCam() { return backCam; }
    }
}
