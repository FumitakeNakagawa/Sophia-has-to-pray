﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Tutorial
{
	public class AccelerationScript : MonoBehaviour
	{
		//現在の加速度
		private Vector3 acceleration;
		//1つ前の加速度
		private Vector3 preAcceleration;
		//振っている
		[SerializeField]
		bool isOnLight;
		//振り誤反応防止タイマー(0.5秒)
		int timer;

		void Start()
		{
			timer = 0;
			isOnLight = true;
		}

		void Update()
		{
			if (timer > 0)timer--;

			ShakeCheck();
		}

		void ShakeCheck()
		{
			preAcceleration = acceleration;
			acceleration = Input.acceleration;

			if (Vector3.Dot(acceleration, preAcceleration) < 0 && timer <= 0)
			{
				isOnLight = !isOnLight;
				timer = 30;
			}
		}

		public bool getIsOnLight()
		{
			return isOnLight;
		}
	}
}
