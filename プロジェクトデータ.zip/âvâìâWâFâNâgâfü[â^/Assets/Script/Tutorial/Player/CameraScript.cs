﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Tutorial
{
	public class CameraScript : MonoBehaviour
	{
		[SerializeField]
		GameManager_TutorialScript GameManager;

		//歩き揺れ
		/*周期*/
		[SerializeField]
		Vector2 period;
		/*振幅*/
		[SerializeField]
		Vector2 amplitude;
		/*指数*/
		[SerializeField]
		int exponent;

		/*プレイヤー*/
		[SerializeField]
		GameObject player;
		/*プレイヤーの位置*/
		private Vector3 playerPosition;
		/*プレイヤーの角度*/
		private Quaternion playerRotation;

		/*カメラ*/
		new private Camera camera;
		/*フォグスクリプト*/
		private main.FogScript fog;

		//ゲームオーバー演出関連
		/*周期*/
		private float shakePeriod;
		/*振幅*/
		private float randomAmplitude;
		/*増加値*/
		private float val;

		void Start()
		{
			camera = gameObject.GetComponent<Camera>();
			fog = gameObject.GetComponent<main.FogScript>();

			playerPosition = player.transform.position;
			playerRotation = player.transform.rotation;

			shakePeriod = 0.0f;
			val = 20.0f;
			randomAmplitude = Random.Range(0.1f, 0.25f);
		}

		void Update()
		{
			camera.backgroundColor = fog.getColor();

			playerPosition = player.transform.position;
			playerRotation = player.transform.rotation;

			//歩き揺れ
			playerPosition.x += Mathf.Sin(playerPosition.z * period.x) * amplitude.x;
			playerPosition.y += Mathf.Cos(playerPosition.z * period.y) * amplitude.y;

			//ゲームオーバー演出
			if (GameManager.GetState() == GameManager_TutorialScript.STATE.GAME_OVER)
			{
				shakePeriod += val;
				if (shakePeriod > 360.0f || shakePeriod < -360.0f)
				{
					val = -val;
					randomAmplitude = Random.Range(0.1f, 0.25f);
				}
				playerPosition.x += Mathf.Sin(shakePeriod * 0.02f) * randomAmplitude;
				playerPosition.y += Mathf.Cos(shakePeriod * 0.01f) * 0.05f;
				playerRotation *= Quaternion.AngleAxis(Mathf.Sin((shakePeriod) * 0.01f) * 8, Vector3.forward * -1.0f);
			}

			transform.position = playerPosition;
			transform.rotation = playerRotation;
		}

		float FluctuationX(float x)
		{
			float val = 0.0f;
			for (int i = 0; i <= exponent; i++)
			{
				val += Mathf.Pow(2, -i) * Mathf.Sin(Mathf.Pow(2, i) * x);
			}
			return val;
		}

		float FluctuationY(float y)
		{
			float val = 0.0f;
			for (int i = 0; i <= exponent; i++)
			{
				val += Mathf.Pow(2, -i) * Mathf.Cos(Mathf.Pow(2, i) * y);
			}
			return val;
		}

	}
}
