﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Tutorial
{
	public class PlayerScript : MonoBehaviour
	{
		private TouchScript touchScript;
		private GyroSensorScript gyroScript;
		private SwipeScript swipeScript;

        //足音SE
        [SerializeField]
		GameObject walk;

		[SerializeField]
		GameManager_TutorialScript GameManagerScript;

		public GameManager_TutorialScript GetGameManager() { return GameManagerScript; }

		// Use this for initialization
		void Start()
		{
			touchScript = GetComponent<TouchScript>();
			gyroScript = GetComponent<GyroSensorScript>();
			swipeScript = GetComponent<SwipeScript>();
		}

		// Update is called once per frame
		void Update()
		{

			if (GameManagerScript.GetState() == GameManager_TutorialScript.STATE.PLAY)
			{
				if (!touchScript.IsPray())
					Singleton<SoundManagerScript>.instance.PlaySE("se_walk", walk);

				//if (!swipeScript.IsBackCam() && swipeScript.t == 1)
				//	transform.rotation = gyroScript.GetRotation();
				//else

				transform.rotation = swipeScript.GetRotation();
			}
			else if (GameManagerScript.GetState() == GameManager_TutorialScript.STATE.GAME_OVER)
				this.enabled = false;

		}


	}
}