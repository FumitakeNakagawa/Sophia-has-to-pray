﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Tutorial
{
	public class LightPowerScript : MonoBehaviour
	{
		/*スライダースクリプト*/
		[SerializeField]
		Slider slider;
		/*割合*/
		[SerializeField]
		float rate;
		/*スライダー初期値*/
		[SerializeField,Range(1, 6)]
		float start = 3.5f;

		void Start()
		{
			/*スライダー最大値*/
			slider.maxValue = 6;
			/*スライダー最小値*/
			slider.minValue = 1;
			/*スライダー初期値*/
			slider.value = start;
		}

		public void LightPower(LightScript light)
		{
			//3～6の範囲に(光量)
			rate = ToRange(slider.maxValue, slider.minValue, 6, 3, slider.value);
			light.getLight().intensity = rate;

			//0.2～0.4の範囲に(フォグ濃度)
			for (int i = 0; i < light.getFog().Count; i++)
			{
				//値が減っていって欲しいから0.3fと0.2fが逆
				light.getFog()[i].setDensity(ToRange(6, 3, 0.2f, 0.4f, rate));
			}

			//10～30の範囲に(光範囲)
			light.getLight().range = ToRange(6, 3, 30, 10, rate);

			//0.0026～0.0078の範囲に(消費量)
			light.setConsumption(ToRange(6, 3, 0.0078f, 0.0026f, rate));
		}

		//fromの範囲からtoの範囲に変換
		float ToRange(float fromMax, float fromMin, float toMax, float toMin, float value)
		{
			float rate = (toMax-toMin) / (fromMax- fromMin);

			return value * rate + (toMin - (fromMin * rate));
		}
	}
}
