﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class PressedFadeScript : MonoBehaviour
{
    Image image;
    Color color;
    float a;

    bool fade;

    [SerializeField]
    float speed;

    float time;
    float flashTime;
    string SceneName;

    bool loadStart;

    AsyncOperation loading;


    public bool CanLoadStart() { return loadStart; }

    // Use this for initialization
    void Start()
    {
        image = GetComponent<Image>();
        color = new Color(1, 1, 1, 0);
        a = 1;
        loadStart = false;
        Singleton<SoundManagerScript>.instance.PlaySE("se_select", gameObject);

    }

    public void Start(string SceneName)
    {
        Start();
        this.SceneName = SceneName;
        time = 0;
        flashTime = 0;
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        flashTime += Time.deltaTime;
        color.a = a;
        image.color = color;

        if (flashTime > 0.05f)
        {
            image.enabled = !image.enabled;
            flashTime = 0f;
        }
        if (time > 0.5f)
        {
            //StartCoroutine(LoadScene());
            loadStart = true;
        }
    }
}
