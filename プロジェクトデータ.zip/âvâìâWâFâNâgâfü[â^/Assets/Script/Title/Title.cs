﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


namespace Title
{
    public class Title : MonoBehaviour
    {
        static bool firstPlay = true;


        [System.Serializable]
        struct Group
        {
            [SerializeField]
            public GameObject obj;

            [SerializeField, Range(0f, 5f), Header("フェードインの速さ")]
            public float fadePlusSpeed;

            [SerializeField, Range(0f, 5f), Header("フェードアウトの速さ")]
            public float fadeMinusSpeed;

            //イメージクラス
            [HideInInspector]
            public RawImage rawImage;
            [HideInInspector]
            public Image image;

            //アルファ値
            [HideInInspector]
            public float a;

            //フェードフラグ(折り返し用)
            [HideInInspector]
            public bool fadeFlg;

            [HideInInspector]
            public bool endflg;

            [HideInInspector]
            public float timer;

            [SerializeField,]
            public float waitTimer;

            //初期カラー
            [SerializeField]
            public Color startColor;

            public void Init(bool fadeFlg)
            {
                rawImage = obj.GetComponent<RawImage>();
                if (rawImage == null)
                    this.image = this.obj.GetComponent<Image>();
                this.fadeFlg = fadeFlg;
                this.endflg = false;
                this.timer = 0;

                GetImage().color = startColor;

            }

            public MaskableGraphic GetImage() { if (rawImage) return rawImage; else return image; }

            public void Update()
            {
                if (!fadeFlg)
                    a += fadePlusSpeed * Time.deltaTime;
                else
                    a -= fadeMinusSpeed * Time.deltaTime;

                a = Mathf.Max(0, a);
                a = Mathf.Min(1, a);
                Color col = GetImage().color;
                GetImage().color = new Color(col.r, col.g, col.b, a);
            }

        }
        [SerializeField, Header("______________________________________________")]
        Group Rec, BG, TTS, moya, logo, light, fade;
        [Header("___________________________________"), Space]

        [SerializeField, Header("難易度選択のグループ")]
        GameObject DifficultGroup;

        public GameObject GetDiffcultGroup() { return DifficultGroup; }


        public struct Difficult
        {
            public enum STATE
            {
                NO_CLEAR,
                CLEAR,
            }

            public GameObject parent;
            public GameObject clear;
            public GameObject pressed;
            public STATE state;
            public Color color;

            public void Init()
            {
                state = STATE.NO_CLEAR;
                color = new Color(1, 1, 1, 1);
            }

            public bool Load(GameObject parent, string objName)
            {
                if (parent == null) return false;
                this.parent = parent.transform.Find(objName).gameObject;
                clear = this.parent.transform.Find("CLEAR").gameObject;
                pressed = this.parent.transform.Find("Pressed " + objName).gameObject;

                return true;
            }

            public void Activate()
            {
                parent.SetActive(true);

                if (state == STATE.NO_CLEAR)
                    clear.SetActive(false);
                else
                    clear.SetActive(true);

            }
        }

        public static Difficult[] difficult;


        [SerializeField, Header("シーンの名前")]
        string[] SceneName;
        int sceneIndex;

        [SerializeField]
        main.GameManagerScript.DIFFICULTY difficulty;

        [SerializeField]
        Sprite touched;//touch

        bool touchedTTS;

        public enum STEP
        {
            RECOMMEND_HEADPHONE,
            TITLE_FADE,
			TITLE_BGM,
			LOGO_FADE,
            TOUCH_THE_SCREEN,
            DIFFICULTY_SELECT,
            FADE_OUT,
            LOADING
        };

        STEP step;

        [SerializeField]
        float time;

        PressedFadeScript pressFadeScript;


        /******************************************************************************************
         * 
         *      ロード画面
         * 
         ******************************************************************************************/
        [System.Serializable]
        struct Loading
        {

            public AsyncOperation async;

            public GameObject parent;
            public Image BG;
            public void Update_BG()
            {
                Color col = BG.color;
                col.a += 2.5f * Time.deltaTime;
                col.a = Mathf.Min(col.a, 1.0f);

                BG.color = col;
            }

            [Header("___________________________________________")]
            [Header("                                  Text関係")]

            [SerializeField]
            Text text;
            float textTimer;
            public float textTimerChange;
            public string[] textOffset;
            int textIndex;

            public void Update_Text()
            {
                textTimer += Time.deltaTime;
                if (textTimer > textTimerChange)
                {
                    textTimer = 0;
                    textIndex++;
                    if (textIndex >= textOffset.Length) textIndex = 0;
                }

                if (async.progress < 0.9f)
                    text.text = textOffset[textIndex];
                else
                    text.text = textOffset[textOffset.Length - 1];
            }


            [Header("___________________________________________")]
            [Header("                                Story関係")]
            public GameObject ImageObj;

			public Image storyImage;
            public Sprite[] storySprite;
            public int storyIndex;
            public float storyTimer;
            public float[] storyTimerChange;

            public void Update_Story()
            {



            }


            [Header("___________________________________________")]
            [Header("                                  その他")]

            public Image fadeImage;
            public bool fadeOutStart;
            public bool fadeInStart;
            public float fadeSpeed;
            public bool fadeEnd;
            bool start;

            //画面のフェードイン・アウト
            void FadeOut()
            {
                Color col = fadeImage.color;
                col.a += fadeSpeed * Time.deltaTime;

                col.a = Mathf.Min(col.a, 1.0f);
                fadeImage.color = col;
                if (storyIndex == storySprite.Length - 1 && col.a >= 1f)
                    async.allowSceneActivation = true;
                else if (col.a >= 1f)
                {
                    storyIndex++;
                    fadeInStart = true;
                    fadeOutStart = false;
                }
            }

            void FadeIn()
            {
                Color col = fadeImage.color;
                col.a -= fadeSpeed * Time.deltaTime;

                col.a = Mathf.Max(col.a, 0.0f);
                fadeImage.color = col;
                if (col.a <= 0f)
                {
                    
                    fadeInStart = false;
                    
                }
            }


            public void Start()
            {
                textIndex = 0;
                text.text = textOffset[textIndex];
                storyIndex = 0;
                storyImage.sprite = storySprite[storyIndex];
                async = null;
                fadeOutStart = false;
                fadeInStart = false;
                start = false;
            }

            public void Update()
            {
                Update_BG();

                if (fadeOutStart)
                    FadeOut();
                else if (fadeInStart)
                    FadeIn();
                else if (async.progress >= 0.9f && start)
                {

                }
                if (storyIndex >= storySprite.Length)
                {
                    storyIndex = storySprite.Length - 1;
                    start = true;
                }

                //最後のページの時
			if(storyIndex == storySprite.Length-1)
					Singleton<SoundManagerScript>.instance.StopBGM(2.0f);

                //表示するページを・テキスト変更している
                storyImage.sprite = storySprite[storyIndex];
                text.text = textOffset[storyIndex];

            }

            //次ページ(シーンではない)へ移動
            public void NextPage()
            {
                fadeOutStart = true;

			}
		}


        [Space]
        [SerializeField, Header("**********************ロード画面****************************")]
        [Space]
        Loading loading;
		public GameObject Page;

		//**********************************************************************
		//
		// Use this for initialization
		//
		//*********************************************************************
		void Start()
        {

            if (firstPlay)
            {
                difficult = new Difficult[3];
                foreach (var it in difficult)
                    it.Init();
            }

            TTS.obj.SetActive(false);

            Rec.Init(false);
            BG.Init(false);
            TTS.Init(false);
            moya.Init(false);
            logo.Init(false);
            light.Init(false);
            fade.Init(false);
            loading.Start();
            difficult[0].Load(DifficultGroup, "EASY");
            difficult[1].Load(DifficultGroup, "NORMAL");
            difficult[2].Load(DifficultGroup, "HARD");


            if (firstPlay)
                step = STEP.RECOMMEND_HEADPHONE;
            else
                step = STEP.TITLE_BGM;
            touchedTTS = false;



            foreach (var it in difficult)
                it.parent.SetActive(false);

            time = 0;

            //  DontDestroyOnLoad(gameObject);

        }

        // Update is called once per frame
        void Update()
        {
            if (firstPlay)
                FirstExecute();
            else
                Execute();

            if (BG.fadeFlg)
            {
                moya.Update();
                if (moya.a == 1 || moya.a == 0)
                    moya.fadeFlg = !moya.fadeFlg;

                light.Update();
                if (light.a == 1)
                    light.fadeFlg = true;

                BG.a -= light.a * 0.5f * 0.0625f * Time.deltaTime;
                BG.GetImage().color = new Color(1, 1, 1, BG.a);
            }
            Singleton<SoundManagerScript>.instance.Update();

        }

		//初回起動
        //(フェードイン→演出→フェードアウトの順番で進んでいる)
		void FirstExecute()
		{
			switch (step)
			{
				case STEP.RECOMMEND_HEADPHONE:
					Rec.Update();

					if (Rec.a == 1)
						Rec.timer += Time.deltaTime;

					if (Rec.timer > Rec.waitTimer)
						Rec.fadeFlg = true;

					if (Rec.a == 0)
					{
						Singleton<SoundManagerScript>.instance.PlayBGM("bgm_title", 0.0f, true);
						step = STEP.TITLE_FADE;
					}

					break;
				case STEP.TITLE_FADE:
					BG.Update();

					if (BG.a == 1)
					{
						step = STEP.LOGO_FADE;
						BG.fadeFlg = true;
					}
					break;
				case STEP.LOGO_FADE:
					logo.Update();
					if (logo.a == 1)
					{
						step = STEP.TOUCH_THE_SCREEN;
					}
					break;
				case STEP.TOUCH_THE_SCREEN:
					BG.fadeFlg = true;
					BG.a = 1;
					BG.GetImage().color = new Color(0, 0, 0, BG.a);
					logo.a = 1;
					logo.GetImage().color = new Color(1, 1, 1, logo.a);

					TTS.obj.SetActive(true);
					TTS.Update();
					if (TTS.a == 1 || TTS.a == 0)
						TTS.fadeFlg = !TTS.fadeFlg;
					if (touchedTTS)
					{
						step = STEP.DIFFICULTY_SELECT;
						TTS.obj.SetActive(false);
						DifficultGroup.SetActive(true);
					}
					break;
				case STEP.DIFFICULTY_SELECT:

					for (int index = 0; index < difficult.Length; index++)
					{
						if (index == difficult.Length - 1)
						{
//                            if (difficult[0].state == Difficult.STATE.CLEAR && difficult[1].state == Difficult.STATE.CLEAR)
                                difficult[index].Activate();
						}
						else
							difficult[index].Activate();
					}
					if (pressFadeScript)
						if (pressFadeScript.CanLoadStart())
						{
							step = STEP.FADE_OUT;
							//loading.parent.SetActive(true);
							fade.obj.SetActive(true);
						}
					break;

				case STEP.FADE_OUT:
					fade.Update();
					if (fade.a == 1)
					{
						step = STEP.LOADING;
						loading.parent.SetActive(true);
						StartCoroutine(LoadScene(SceneName[sceneIndex]));
					}
					//BG.obj.SetActive(false);
					break;
				case STEP.LOADING:

					loading.Update();

					break;

			}

		}

		void Execute()
		{
			BG.fadeFlg = true;
			switch (step)
			{
				case STEP.TITLE_BGM:
					Singleton<SoundManagerScript>.instance.PlayBGM("bgm_title", 0.0f, true);
					step = STEP.TOUCH_THE_SCREEN;
					break;
				case STEP.TOUCH_THE_SCREEN:
					logo.obj.SetActive(true);
					logo.a = 1;
					logo.Update();
					TTS.obj.SetActive(true);
					BG.a = 1;
					TTS.Update();
					if (TTS.a == 1 || TTS.a == 0)
						TTS.fadeFlg = !TTS.fadeFlg;
					if (touchedTTS)
					{
						step = STEP.DIFFICULTY_SELECT;
						TTS.obj.SetActive(false);
						DifficultGroup.SetActive(true);
					}
					break;

				case STEP.DIFFICULTY_SELECT:
					for (int index = 0; index < difficult.Length; index++)
					{
						if (index == difficult.Length - 1)
						{
                           // if (difficult[0].state == Difficult.STATE.CLEAR && difficult[1].state == Difficult.STATE.CLEAR)
                                difficult[index].Activate();
						}
						else
							difficult[index].Activate();
					}

					if (pressFadeScript)
						if (pressFadeScript.CanLoadStart())
						{
							step = STEP.FADE_OUT;
							//loading.parent.SetActive(true);
							fade.obj.SetActive(true);
						}
					break;

				case STEP.FADE_OUT:
					fade.Update();
					if (fade.a == 1)
					{
						step = STEP.LOADING;
						loading.parent.SetActive(true);
						StartCoroutine(LoadScene(SceneName[sceneIndex]));
					}
					//BG.obj.SetActive(false);
					break;
				case STEP.LOADING:

					loading.Update();

					break;


			}
		}

		//初回起動後のシーン切り替え時にフラグを立ててる
		private void OnLevelWasLoaded(int level)
        {

            if (firstPlay)
                firstPlay = false;
        }

        //画面にTouch The Screenの文字が出てるときに画面タッチ(ボタン押した)したときに呼び出す関数
        public void TouchedTheScreen()
        {
            Singleton<SoundManagerScript>.instance.PlaySE("se_start", gameObject);
            touchedTTS = true;
        }

        //シーン切り替え(引数はそれぞれのシーンのインデックス番号)
        public void ChangeScene(int Index)
        {
            //Singleton<SoundManagerScript>.instance.StopBGM(1.5f);

            if (difficult[Index].pressed.GetComponent<PressedFadeScript>() == null)
                difficult[Index].pressed.AddComponent<PressedFadeScript>();
            pressFadeScript = difficult[Index].pressed.GetComponent<PressedFadeScript>();

            sceneIndex = Index;
        }

        //ロード中
        public IEnumerator LoadScene(string sceneName)
        {
            loading.async = SceneManager.LoadSceneAsync(sceneName);
            loading.async.allowSceneActivation = false;
            //Singleton<SoundManagerScript>.instance.PlayBGM("bgm_main", 0.1f, true);
            while (!loading.async.isDone)
            {
                yield return null;
            }
        }


		public void NextPage()
		{
			loading.NextPage();
		}

        
		public void NextPage2()
		{
			loading.NextPage();
			Singleton<SoundManagerScript>.instance.PlaySE2("se_page", Page);

		}
	}
}
