﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGMPlayer
{

	class State
	{
		protected BGMPlayer bgmPlayer;
		public State(BGMPlayer bgmPlayer)
		{
			this.bgmPlayer = bgmPlayer;
		}
		public virtual void PlayBGM() { }
		public virtual void PauseBGM() { }
		public virtual void StopBGM() { }
		public virtual void Update() { }
	}

	//待機中遷移
	class Wait : State
	{
		public Wait(BGMPlayer bgmPlayer) : base(bgmPlayer) { }

		public override void PlayBGM()
		{
			if (bgmPlayer.fadeInTime > 0.0f) bgmPlayer.state = new FadeIn(bgmPlayer);
			else bgmPlayer.state = new Playing(bgmPlayer);
		}
	}

	//フェードイン遷移
	class FadeIn : State
	{
		float t = 0.0f;

		public FadeIn(BGMPlayer bgmPlayer):base(bgmPlayer)
		{
			bgmPlayer.source.Play();
			bgmPlayer.source.volume = 0.0f;
		}

		public override void PauseBGM()
		{
			bgmPlayer.state = new Pause(bgmPlayer, this);
		}

		public override void StopBGM()
		{
			bgmPlayer.state = new FadeOut(bgmPlayer);
		}

		public override void Update()
		{
			t += Time.deltaTime;
			bgmPlayer.source.volume = t / bgmPlayer.fadeInTime*0.5f;
			if (t >= bgmPlayer.fadeInTime)
			{
				bgmPlayer.source.volume = 0.5f;
				bgmPlayer.state = new Playing(bgmPlayer);
			}
		}
	}

	//再生中遷移
	class Playing : State
	{
		public Playing(BGMPlayer bgmPlayer) : base(bgmPlayer)
		{
			if (bgmPlayer.source.isPlaying == false)
			{
				bgmPlayer.source.volume = 0.5f;
				bgmPlayer.source.Play();
			}
		}

		public override void PauseBGM()
		{
			bgmPlayer.state = new Pause(bgmPlayer, this);
		}

		public override void StopBGM()
		{
			bgmPlayer.state = new FadeOut(bgmPlayer);
		}
	}

	//ポーズ中遷移
	class Pause : State
	{
		State preState;

		public Pause(BGMPlayer bgmPlayer, State preState) : base(bgmPlayer)
		{
			this.preState = preState;
			bgmPlayer.source.Pause();
		}

		public override void StopBGM()
		{
			bgmPlayer.source.Stop();
			bgmPlayer.state = new Wait(bgmPlayer);
		}

		public override void PlayBGM()
		{
			bgmPlayer.state = preState;
			bgmPlayer.source.Play();
		}
	}

	//フェードアウト遷移
	class FadeOut : State
	{
		float initVolume;
		float t = 0.0f;

		public FadeOut(BGMPlayer bgmPlayer) : base(bgmPlayer)
		{
			initVolume = bgmPlayer.source.volume;
		}

		public override void PauseBGM()
		{
			bgmPlayer.state = new Pause(bgmPlayer, this);
		}

		public override void Update()
		{
			t += Time.deltaTime;
			bgmPlayer.source.volume = initVolume * (1.0f - t / bgmPlayer.fadeOutTime);
			if (t >= bgmPlayer.fadeOutTime)
			{
				bgmPlayer.source.volume = 0.0f;
				bgmPlayer.source.Stop();
				bgmPlayer.state = new Wait(bgmPlayer);
				bgmPlayer.fadeFlag = true;
			}
		}
	}

	GameObject obj;
	AudioSource source;
	State state;
	float fadeInTime = 0.0f;
	float fadeOutTime = 0.0f;
	bool fadeFlag = false;

	public BGMPlayer() { }

	public BGMPlayer(string bgmFileName,bool loop)
	{
		AudioClip clip = (AudioClip)Resources.Load(bgmFileName);

		if(clip!=null)
		{
			obj = new GameObject("BGMPlayer");
			source = obj.AddComponent<AudioSource>();
			source.clip = clip;
			source.loop = loop;
			state = new Wait(this);
		}
		else
		{
			Debug.Log("BGM " + bgmFileName + " is not found");
		}
	}

	public void Destory()
	{
		if (source != null) Object.Destroy(obj);
	}

	//再生
	public void PlayBGM()
	{
		if (source != null) state.PlayBGM();
	}

	public void PlayBGM(float fadeTime)
	{
		if (source != null)
		{
			fadeInTime = fadeTime;
			state.PlayBGM();
		}
	}

	//ポーズ
	public void PauseBGM()
	{
		if (source != null) state.PauseBGM();
	}

	//停止
	public void StopBGM(float fadeTime)
	{
		if (source != null)
		{
			fadeOutTime = fadeTime;
			state.StopBGM();
		}
	}

	//フェードアウトしきったか
	public bool HadFadeOut()
	{
		return fadeFlag;
	}

	public void Update()
	{
		if (source != null) state.Update();
	}

}
