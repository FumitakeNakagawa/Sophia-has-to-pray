﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManagerScript:MonoBehaviour
{
	/*音源*/
	GameObject soundPlayer;
	AudioSource audioSource;
	Dictionary<string, AudioClipInfo> audioClips = new Dictionary<string, AudioClipInfo>();

	/*現在のBGM*/
	BGMPlayer curBGMPlayer;
	/*フェード中のBGM*/
	BGMPlayer fadeOutBGMPlayer;

	AudioSource[] resources;
	float[] initVolume;
	int cut = 0;
	float t = 0.0f;
	bool isFade = false;

	/*オーディオクリップ情報*/
	class AudioClipInfo
	{
		public string resourceName;
		public string name;
		public AudioClip clip;
		//ボリューム
		public float volume = 1.0f;

		public AudioClipInfo(string resourceName, string name, float volume = 1.0f)
		{
			this.resourceName = resourceName;
			this.name = name;
			this.volume = volume;
		}
	}

	/*サウンド名とサウンドファイル名を対にして登録*/
	public SoundManagerScript()
	{
		/*TITLE*/
		//BGM
		audioClips.Add("bgm_title", new AudioClipInfo("sound\\bgm_sadforest", "bgm_title"));
		//SE
		audioClips.Add("se_start", new AudioClipInfo("sound\\start", "se_start"));
		audioClips.Add("se_select", new AudioClipInfo("sound\\select", "se_select"));
		audioClips.Add("se_page", new AudioClipInfo("sound\\page", "se_page"));

		/*MAIN*/
		//BGM
		audioClips.Add("bgm_main", new AudioClipInfo("sound\\bgm_nightforest", "bgm_main"));
		audioClips.Add("bgm_end", new AudioClipInfo("sound\\bgm_end", "bgm_end"));
		//SE
		audioClips.Add("se_walk", new AudioClipInfo("sound\\walk", "se_walk"));
		audioClips.Add("se_pray", new AudioClipInfo("sound\\pray", "se_pray"));
		audioClips.Add("se_swipe", new AudioClipInfo("sound\\swipe", "se_swipe"));
		audioClips.Add("se_slid", new AudioClipInfo("sound\\slid", "se_slid"));

		audioClips.Add("se_shout", new AudioClipInfo("sound\\shout", "se_shout",0.8f));
		audioClips.Add("se_fire", new AudioClipInfo("sound\\fire", "se_fire"));
		audioClips.Add("se_grass", new AudioClipInfo("sound\\grass", "se_grass"));
		audioClips.Add("se_crow", new AudioClipInfo("sound\\crow", "se_crow"));
		audioClips.Add("se_wind", new AudioClipInfo("sound\\draftofwind", "se_wind"));
		audioClips.Add("se_insect", new AudioClipInfo("sound\\insect", "se_insect"));
		audioClips.Add("se_beats", new AudioClipInfo("sound\\heartbeat", "se_beats"));
		audioClips.Add("se_fearend", new AudioClipInfo("sound\\fearend", "se_fearend"));
		audioClips.Add("se_wolf", new AudioClipInfo("sound\\wolf", "se_wolf"));
		audioClips.Add("se_gleam", new AudioClipInfo("sound\\gleam", "se_gleam",0.3f));
        audioClips.Add("se_tutorial", new AudioClipInfo("sound\\SE_Tutorial", "se_tutorial", 1.0f));

    }

    /*指定された名前のSEを再生*/
    public bool PlaySE(string seName, GameObject obj)
	{
		if (audioClips.ContainsKey(seName) == false) return false;

		AudioClipInfo info = audioClips[seName];

		//ロード
		if (info.clip == null)
		{
			info.clip = (AudioClip)Resources.Load(info.resourceName);
			if (info.clip == null) Debug.LogWarning("SE " + seName + " is not found");
		}

		//オーディオソースが無ければ作る
		if (obj.GetComponent<AudioSource>() == null)
		{
			obj.AddComponent<AudioSource>();
			audioSource = obj.GetComponent<AudioSource>();
			audioSource.volume = info.volume;
		}
		else
		{
			audioSource = obj.GetComponent<AudioSource>();
		}

		audioSource.spatialBlend = 0.0f;

		//再生
		if (!audioSource.isPlaying)
		{
			audioSource.PlayOneShot(info.clip, info.volume);
			return true;
		}

		return false;
	}

	public bool PlaySE2(string seName, GameObject obj)
	{
		if (audioClips.ContainsKey(seName) == false) return false;

		AudioClipInfo info = audioClips[seName];

		//ロード
		if (info.clip == null)
		{
			info.clip = (AudioClip)Resources.Load(info.resourceName);
			if (info.clip == null) Debug.LogWarning("SE " + seName + " is not found");
		}

		//オーディオソースが無ければ作る
		if (obj.GetComponent<AudioSource>() == null)
		{
			obj.AddComponent<AudioSource>();
			audioSource = obj.GetComponent<AudioSource>();
			audioSource.volume = info.volume;
		}
		else
		{
			audioSource = obj.GetComponent<AudioSource>();
		}

		audioSource.spatialBlend = 0.0f;

			audioSource.PlayOneShot(info.clip, info.volume);
			return true;
	}

	/*指定された名前のSEを再生(3D)*/
	public bool Play3DSE(string seName, GameObject obj)
	{
		if (audioClips.ContainsKey(seName) == false) return false;

		AudioClipInfo info = audioClips[seName];

		//ロード
		if (info.clip == null)
		{
			info.clip = (AudioClip)Resources.Load(info.resourceName);
			if (info.clip == null) Debug.LogWarning("SE " + seName + " is not found");
		}

		if (obj.GetComponent<AudioSource>() == null) Debug.LogWarning(obj + "audio source not found");
		audioSource = obj.GetComponent<AudioSource>();
		//3D設定
		audioSource.spatialBlend = 1.0f;
		//フェードし続ける距離
		//audioSource.maxDistance = 5.0f;

		//再生
		if (!audioSource.isPlaying) audioSource.PlayOneShot(info.clip, info.volume);

		return true;
	}

	public void Update()
	{
		if (curBGMPlayer != null) curBGMPlayer.Update();
		if (fadeOutBGMPlayer != null) fadeOutBGMPlayer.Update();

		if(isFade)
		{
			t += Time.deltaTime;

			foreach (var obj in resources)
			{
				if (obj != null && obj.name != "GameManager")
				{
					obj.volume = initVolume[cut] * (1.0f - t / 3.0f);
					if (obj.volume <= 0.0f)
					{
						obj.volume = 0.0f;
					}
					cut++;
				}
			}
			cut = 0;
		}
	}

	/*BGMを再生*/
	public void PlayBGM()
	{
		if (curBGMPlayer != null && curBGMPlayer.HadFadeOut() == false) curBGMPlayer.PlayBGM();
		if (fadeOutBGMPlayer != null && fadeOutBGMPlayer.HadFadeOut() == false) fadeOutBGMPlayer.PlayBGM();
	}

	/*指定されたBGM名のBGMを再生*/
	public void PlayBGM(string bgmName, float fadeTime, bool loop)
	{
		//現在フェードアウト中のBGMを消す
		if (fadeOutBGMPlayer != null) fadeOutBGMPlayer.Destory();

		//現在のBGMをフェードアウトに変更
		if (curBGMPlayer != null)
		{
			curBGMPlayer.StopBGM(fadeTime);
			fadeOutBGMPlayer = curBGMPlayer;
		}

		//次のBGMを流す
		if (audioClips.ContainsKey(bgmName) == false)
		{
			curBGMPlayer = new BGMPlayer();
		}
		else
		{
			curBGMPlayer = new BGMPlayer(audioClips[bgmName].resourceName, loop);
			curBGMPlayer.PlayBGM(fadeTime);
		}
	}

	/*BGMを一時停止*/
	public void PauseBGM()
	{
		if (curBGMPlayer != null) curBGMPlayer.PauseBGM();
		if (fadeOutBGMPlayer != null) fadeOutBGMPlayer.PauseBGM();
	}

	/*BGMを停止*/
	public void StopBGM(float fadeTime)
	{
		if (curBGMPlayer != null) curBGMPlayer.StopBGM(fadeTime);
		if (fadeOutBGMPlayer != null) fadeOutBGMPlayer.StopBGM(fadeTime);
	}

	public void MuteSound()
	{
		if (!isFade)
		{
			resources = Resources.FindObjectsOfTypeAll<AudioSource>();
			initVolume = new float[resources.Length];
			foreach (var obj in resources)
			{

				if (obj.name != "GameManager")
				{
					initVolume[cut] = obj.volume;
					cut++;
				}
			}
			cut = 0;
			isFade = true;
		}
	}

	public void UnMuteSound()
	{
		foreach (var obj in Resources.FindObjectsOfTypeAll<AudioSource>())
		{
			if (obj != null && obj.name != "GameManager")
			{
				obj.mute = false;
				isFade = false;
			}
		}
	}

}