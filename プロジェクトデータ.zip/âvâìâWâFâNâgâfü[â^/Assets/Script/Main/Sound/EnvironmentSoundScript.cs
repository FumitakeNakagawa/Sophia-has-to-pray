﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnvironmentSoundScript : MonoBehaviour
{
	//プレイヤー
	[SerializeField]
	GameObject player;
	//サウンドタイマー
	private float timer;
	//サウンドタイプ
	private int type;

	private enum SOUNDTYPE
	{
		SE_GRASS,
		SE_CROW,
		SE_WIND,
		SE_INSECT,
		SE_WOLF,
		SE_MAX
	}

	void Start()
	{
		//5～10秒ランダム
		timer = Random.Range(5, 15);
		//SEランダム
		type = Random.Range((int)SOUNDTYPE.SE_GRASS, (int)SOUNDTYPE.SE_MAX);
	}

	void Update()
	{
		if ((timer -= Time.deltaTime) <= 0)
		{
			//対象オブジェクト
			GameObject se = null;

			//位置ランダム
			Vector3 randPos = player.transform.position;
			float val = Random.Range(-0.5f * Mathf.PI, 0.5f * Mathf.PI);
			randPos.x += Mathf.Sin(val) * 3;
			randPos.z += Mathf.Cos(val) * 3;

			foreach (Transform child in transform)
			{
				switch (type)
				{
					case (int)SOUNDTYPE.SE_GRASS:
						if (child.name == "Grass")
						{
							se = child.gameObject;
							Singleton<SoundManagerScript>.instance.Play3DSE("se_grass", se);
							randPos.y = 0;
						}
						break;
					case (int)SOUNDTYPE.SE_CROW:
						if (child.name == "Crow ")
						{
							se = child.gameObject;
							Singleton<SoundManagerScript>.instance.Play3DSE("se_crow", se);
							randPos.y = 5;
						}
						break;
					case (int)SOUNDTYPE.SE_WIND:
						if (child.name == "Wind")
						{
							se = child.gameObject;
							Singleton<SoundManagerScript>.instance.PlaySE("se_wind", se);
						}
						break;
					case (int)SOUNDTYPE.SE_INSECT:
						if (child.name == "Insect")
						{
							se = child.gameObject;
							Singleton<SoundManagerScript>.instance.Play3DSE("se_insect", se);
							randPos.y = 0;
						}
						break;
					case (int)SOUNDTYPE.SE_WOLF:
						if (child.name == "Wolf")
						{
							se = child.gameObject;
							Singleton<SoundManagerScript>.instance.Play3DSE("se_wolf", se);
							randPos *= 3;
							randPos.y = 0;
						}
						break;
				}
			}
			se.transform.position = randPos;

			timer = Random.Range(5, 15);
			type = Random.Range((int)SOUNDTYPE.SE_GRASS, (int)SOUNDTYPE.SE_MAX);
		}
	}
}
