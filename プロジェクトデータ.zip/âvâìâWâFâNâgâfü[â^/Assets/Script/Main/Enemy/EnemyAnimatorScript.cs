﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAnimatorScript : MonoBehaviour {

    Animator animator;
	// Use this for initialization
	void Start ()
    {
        animator = GetComponent<Animator>();
	}

    public void TriggerGameOverFlg() { animator.SetTrigger("GameOver_Flg"); }
    public void SetFind(bool val) { animator.SetBool("Find", val); }
    public void SetBlend(float val) { animator.SetFloat("Blend", val); }
    //public bool GetEnd() { animator.} 
}
