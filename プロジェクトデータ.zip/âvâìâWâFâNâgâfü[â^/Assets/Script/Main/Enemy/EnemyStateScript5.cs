﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace main
{
    [SerializeField]
    public class EnemyStateScript5 : StateScript
    {
        public float speed;
        public Camera camera;
        //public Light spotLight;
        public float apeearInterval;            //出現する間隔(s)

		public AudioSource walk;

		// Use this for initialization
		void Start()
        {
            state = new StateWait();
        }

        [SerializeField]
        public class StateWait : StateScript.State
        {
			AudioSource walk;

			float timeNext;         //次のステートに切り替わるまでの時間
            float time;
            public override void Enter(GameObject enemy)
            {
				walk = enemy.GetComponent<EnemyStateScript5>().walk;
				walk.mute = true;

				time = Time.time;
                timeNext = enemy.GetComponent<EnemyStateScript5>().apeearInterval;
                player = enemy.GetComponent<Enemy2Script>().player;
            }
            public override State DecisionMaking(GameObject enemy)
            {
                if (Time.time >= time + timeNext)
                {
                    //プレイヤーがこちらのほうを向いていたら
                    Vector3 v = enemy.transform.position - player.transform.position;
                    v.y = 0.0f;
                    Vector3 dirPlayer = new Vector3(Mathf.Sin(player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(player.transform.localEulerAngles.y * 0.01745f));
                    //print(Vector3.Dot(v.normalized, dirPlayer.normalized));
                    if (Vector3.Dot(v.normalized, dirPlayer.normalized) < 0.93969f)
                    {
                        return new StateAppear();
                    }
                }
                return null;
            }
        }

        public class StateAppear : StateScript.State
        {
			AudioSource walk;

			const float timeNext = 12.0f;         //次のステートに切り替わるまでの時間
            float time;
            public override void Enter(GameObject enemy)
            {
				walk = enemy.GetComponent<EnemyStateScript5>().walk;
				walk.mute = true;
				time = Time.time;
                player = enemy.GetComponent<Enemy2Script>().player;
                enemy.transform.position = new Vector3(player.transform.position.x, enemy.transform.position.y, player.transform.position.z - 3.0f);
                float angle = TargetToFace(enemy.transform.position, player.transform.position);
                enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, angle, enemy.transform.localEulerAngles.z);
            }
            public override State DecisionMaking(GameObject enemy)
            {
                if (Time.time >= time + timeNext)
                {
                    return new StateStuckUp();
                }

                //if(hideFg)
                {
                    //プレイヤーがこちらのほうを向いていたら
                    Vector3 v = enemy.transform.position - player.transform.position;
                    v.y = 0.0f;
                    Vector3 dirPlayer = new Vector3(Mathf.Sin(player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(player.transform.localEulerAngles.y * 0.01745f));
                    //print(Vector3.Dot(v.normalized, dirPlayer.normalized));
                    if (Vector3.Dot(v.normalized, dirPlayer.normalized) > 0.93969f)
                    {
                        return new StateTurnBack();
                    }
                }

				return null;
            }

		}

		public class StateTurnBack : StateScript.State
        {
			AudioSource walk;

			Camera camera;
            float speed;
            public override void Enter(GameObject enemy)
            {
				walk = enemy.GetComponent<EnemyStateScript5>().walk;

				camera = enemy.GetComponent<EnemyStateScript5>().camera;
                player = enemy.GetComponent<Enemy2Script>().player;
                speed = enemy.GetComponent<EnemyStateScript5>().speed;
                enemy.transform.position = new Vector3(player.transform.position.x, enemy.transform.position.y, player.transform.position.z - 5.0f);
                float angle = TargetBackFace(enemy.transform.position, player.transform.position);
                enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, angle, enemy.transform.localEulerAngles.z);
            }
            public override State DecisionMaking(GameObject enemy)
            {
                if (camera.farClipPlane + 2.0f < Vector3.Distance(enemy.transform.position, player.transform.position))
                {
                    return new StateWait();
                }

                return null;
            }
            public override void Method(GameObject enemy)
            {
                //移動
                Vector3 posPlayer = player.transform.position;
                Vector3 v = new Vector3(enemy.transform.position.x - posPlayer.x, 0.0f, enemy.transform.position.z - posPlayer.z);
                v.Normalize();
                enemy.transform.position += v * speed * Time.deltaTime;
				walk.mute = false;

			}
        }

        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //GAME OVER
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public class StateStuckUp : StateScript.State
        {
            public override void Enter(GameObject enemy)
            {
                state = new StateStuckUpWait();
                state.Enter(enemy);
            }
            public override State DecisionMaking(GameObject enemy)
            {
                return null;
            }
        }

        //待機
        public class StateStuckUpWait : StateStuckUp
        {
            public override void Enter(GameObject enemy)
            {
                print("生成されました");
            }
            public override State DecisionMaking(GameObject enemy)
            {
				//if (enemy.GetComponent<Enemy2Script>().gameManager.GetComponent<GameManagerScript>().GetState() == GameManagerScript.STATE.SHORT_TUTORIAL)
				//	enemy.GetComponent<Enemy2Script>().ChangeState(new StateWait());

                if (!hideFg)
                {

                    Vector3 v = enemy.transform.position - enemy.GetComponent<Enemy2Script>().player.transform.position;
                    Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
                    //print(Vector3.Dot(v.normalized, dirPlayer.normalized));
                    //					if (Vector3.Dot(v.normalized, dirPlayer.normalized) > 0.707f)
                    {
                        print("GAME OVERへ");
                        return new StateStuckGameOver();
                    }
                }
                else
                {
                    hideFg = false;
                }
                return null;
            }
            public override void Method(GameObject enemy)
            {
                //if(hideFg)
                //if (enemy.GetComponent<Enemy2Script>().gameManager.GetComponent<GameManagerScript>().GetState() == GameManagerScript.STATE.SHORT_TUTORIAL) return;

                {
					//位置をプレイヤーの目の前へ
					//Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
					//Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
					//posPlayer.y = 0;
					//Vector3 v = posPlayer - enemy.transform.position;
					//enemy.transform.position = enemy.transform.position + -v.normalized * enemy.GetComponent<Enemy2Script>().GetDeadDist();
					////プレイヤーの方へ向く
					//float rad = Mathf.Acos(Vector3.Dot(v.normalized, Vector3.forward));
					//if (Vector3.Cross(v.normalized, Vector3.forward).y > 0.0f) rad = -rad;
					//enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, rad * 180.0f / Mathf.PI, enemy.transform.localEulerAngles.z);
					//float angle = TargetToFace(enemy.transform.position, posPlayer);
					//enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, angle, enemy.transform.localEulerAngles.z);


				}
                //else if(enemy.GetComponent<Enemy2Script>().pointLight.GetComponent<BatteryScript>().battery <= 0.0f)
                //{
                //    //位置をプレイヤーの目の前へ
                //    Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
                //    Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
                //    enemy.transform.position = posPlayer + dirPlayer.normalized * 3.0f;
                //    //プレイヤーの方へ向く
                //    Vector3 v = posPlayer - enemy.transform.position;
                //    float rad = Mathf.Acos(Vector3.Dot(v.normalized, Vector3.forward));
                //    if (Vector3.Cross(v.normalized, Vector3.forward).y > 0.0f) rad = -rad;
                //    enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, rad * 180.0f / Mathf.PI, enemy.transform.localEulerAngles.z);
                //}
                //else
                //{
                //    //常にプレイヤーの前で待機
                //    Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
                //    Vector3 v = enemy.transform.position - posPlayer;
                //    enemy.transform.position = posPlayer + v.normalized * 3.0f;
                //}
            }
        }

        //GAMEOVER
        public class StateStuckGameOver : StateStuckUp
        {
            public override void Enter(GameObject enemy)
            {
                GameManagerScript gms = enemy.GetComponent<Enemy2Script>().gameManager.GetComponent<GameManagerScript>();
                if (gms.GetState() == GameManagerScript.STATE.PLAY)
                {
                    //Singleton<SoundManagerScript>.instance.PlaySE("se_shout", gms.gameObject);
                    foreach (Transform child in enemy.transform)
                    {
                        child.gameObject.layer = LayerMask.NameToLayer("Water");
                    }
                    //enemy.GetComponent<EnemyStateScript5>().spotLight.enabled = true;
                    //enemy.GetComponent<Enemy2Script>().pointLight.enabled = false;
                    enemy.GetComponent<Enemy2Script>().SetGameOver(true);
                    //enemy.transform.position += Vector3.down;
                    //enemy.transform.localScale += Vector3.one;
                }
            }
            public override State DecisionMaking(GameObject enemy)
            {
                return null;
            }
            public override void Method(GameObject enemy)
            {

            }
        }
    }
}