﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StateScript : MonoBehaviour
{

	public State state;
	public struct VibrateData     //バイブレーションを鳴らす間隔を計算するための情報
	{
		public float maxInterval;      //最大距離以上のときの間隔
		public float minInterval;      //最小距離以下のときの間隔
		public float maxDist;          //最小距離
		public float minDist;          //最大距離
	}

	[System.Serializable]
	//ステート基底クラス
	public class State
	{
		public State state;      //小カテゴリ
		float time;
		bool vibrateFg;
		protected VibrateData vibData;
		protected GameObject player;
		protected float timeBreath;
		protected const float timeBreathInterval = 2.9f;
		protected float timeVib;
		protected long timeVibrate = 800;                              //バイブがなっている間の時間(ms)
		protected float timeVibInterval = 1.0f;                      //バイブがなっていない間の時間(s)
		protected bool hideFg;
		protected bool grassFg;

		public State()
		{
			state = null;
			vibData = new VibrateData();
			vibData.maxInterval = 3.0f;
			vibData.minInterval = 1.0f;
			vibData.maxDist = 10.0f;
			vibData.minDist = 2.0f;
			timeVibrate = 800;
			timeVibInterval = 2.2f;
		}
		public virtual State DecisionMaking(GameObject enemy) { return null; }    //意思決定
		public virtual void Enter(GameObject enemy) { }                //ステートが切り替わった直後
		public virtual void Method(GameObject enemy) { }               //メソッド(振る舞い)
		public virtual void Exit(GameObject enemy) { }             //ステートが切り替わる直前
		public virtual void Message(string mes)
		{
			if (state != null) state.Message(mes);
			if (mes == "hide") hideFg = true;
			if (mes == "grass") grassFg = true;
		}
		public virtual void OnTrrigerEnter(GameObject enemy, Collider collider) { }
		public virtual void OnTrrigerStay(GameObject enemy, Collider collider) { }
		public virtual State Update(GameObject enemy)
		{
			State next, next_min = null;

			Method(enemy);

			next = DecisionMaking(enemy);
			if (state != null)
			{
				next_min = state.Update(enemy);
				if (next_min != null)
				{
					ChangeState(next_min, enemy);
				}
			}

			//else Method(enemy);

			return next;
		}
		//ステート切り替え
		public void ChangeState(State next, GameObject enemy)
		{
			if (state != null)
			{
				state.Exit(enemy);
				//    delete state;
			}

			state = next;
			state.Enter(enemy);
		}
		//初期化
		public void Init(GameObject enemy)
		{
			if (state != null)
			{
				state.Init(enemy);
				state.Exit(enemy);
			}
		}

		//ターゲットへの向き
		protected float TargetToFace(Vector3 pos, Vector3 target)
		{
			//プレイヤーの方へ向く
			Vector3 v = target - pos;
			v.y = 0;

			float rad = Mathf.Acos(Vector3.Dot(v.normalized, Vector3.forward));
			if (Vector3.Cross(v.normalized, Vector3.forward).y > 0.0f) rad = -rad;
			rad = rad * 180.0f / Mathf.PI;
			return rad;
		}

		//ターゲットへ逆の向き
		protected float TargetBackFace(Vector3 pos, Vector3 target)
		{
			//プレイヤーの方へ向く
			Vector3 v = target - pos;
			v.y = 0;

			float rad = Mathf.Acos(Vector3.Dot(v.normalized, Vector3.back));
			if (Vector3.Cross(v.normalized, Vector3.back).y > 0.0f) rad = -rad;
			rad = rad * 180.0f / Mathf.PI;
			return rad;
		}

		////バイブレーションの間隔を計算
		//protected float VibrateInterval(VibrateData data, Vector3 posA, Vector3 posB)
		//{
		//	float interval;
		//	float dist = Vector3.Distance(posA, posB);
		//	interval = (dist - data.minDist) / (data.maxDist - data.minDist) * (data.maxInterval - data.minInterval) + data.minInterval;

		//	return interval;
		//}

		////バイブレーション
		//protected void Vibrate(float interval)
		//{
		//	if (vibrateFg)
		//	{
		//		if (Time.time >= time)
		//		{
		//			vibrateFg = false;
		//		}
		//	}
		//	else
		//	{
		//		vibrateFg = true;
		//		time = Time.time + interval;
		//		Handheld.Vibrate();
		//	}
		//}

		////SE
		//protected void PlaySE(GameObject enemy, string nameObj, string nameSE)
		//{
		//	GameObject se = null;
		//	foreach (Transform child in enemy.transform)
		//	{
		//		if (child.name == nameObj)
		//		{
		//			se = child.gameObject;
		//			break;
		//		}
		//	}
		//	if (se == null) return;
		//	Singleton<SoundManagerScript>.instance.Play3DSE(nameSE, se);
		//}

		////呼吸音
		//protected void Breath(GameObject enemy)
		//{
		//	//if (hideFg)
		//	{
		//		//PlaySE(enemy, "Walk", "se_walk");
		//		//print(Time.time + " : " + timeBreath + timeBreathInterval);
		//		if (Time.time >= enemy.GetComponent<main.Enemy2Script>().timeBreath + timeBreathInterval)
		//		{
		//			PlaySE(enemy, "se_breath", "se_breath");
		//			enemy.GetComponent<main.Enemy2Script>().timeBreath = Time.time;
		//		}
		//		//Vibrate(VibrateInterval(vibData, enemy.transform.position, enemy.GetComponent<Enemy2Script>().player.transform.position));
		//	}
		//}

		////バイブレーション
		//protected bool Vibrate()
		//{
		//	if (hideFg)
		//	{
		//		//振動
		//		if (Time.time >= timeVib + timeVibInterval + (timeVibrate * 0.001f))
		//		{
		//			PluginScript.CallVibrate(timeVibrate);
		//			timeVib = Time.time;
		//			return true;
		//		}
		//	}

		//	return false;
		//}

		public State getState() { return state; }
	}
}