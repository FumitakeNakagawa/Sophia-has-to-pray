﻿//using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace main
{

    public class EnemyStateScript4 : StateScript
    {
        //public Light spotLight;
        //public Shader standard;
        //public Shader Ghost;
        public float speedLeave;                //離れていく速さ
        public float speedLeaveAddMax;          //離れていくのに足される速度の最大値
        public float speedLeaveAddTimeStart;    //速度が足され始める時間
        public float speedLeaveTimeMax;         //足される速度の最大値になるまでの時間
        public float speedLeaveExponent;        //離れる速度がだんだん速くなる度合い
        public float speedApproach;             //プレイヤーが見える範囲での近づいてくる速さ
        public float speedApproachNotLook;      //プレイヤーが見えない範囲での近づいてくる速さ
		public AudioSource walk;
        public new Camera camera;

		//public StateScript.State state;
		void Start()
        {
            state = new StateFind();
            //state = new StateToHaveFace();
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //見つけた状態
        //--------------------------------------------------------------------------------------------------------------------------------------------------------------------
        protected class StateFind : StateScript.State
        {
            public override void Enter(GameObject enemy)
            {
                state = new StateFindMove();
                state.Enter(enemy);
            }
            public override State DecisionMaking(GameObject enemy)
            {
                if (hideFg == false)
                {
                    //近づいたら
                    ////近づいたら
                    Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
                    //if (Vector3.Distance(posPlayer, enemy.transform.position) < 3.0f)
                    //{
                    //    //print("追いついた状態へ");
                    //    return new StateStuckUp();
                    //}

                    Vector3 v = enemy.transform.position - enemy.GetComponent<Enemy2Script>().player.transform.position;
                    Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
                    if (Vector3.Distance(posPlayer, enemy.transform.position) < 3.0f)
                    {
                        //if (Vector3.Dot(v.normalized, dirPlayer.normalized) > 0.86f)
                        if (Vector3.Dot(v.normalized, Vector3.forward) > -0.5f)
                        {
                            print("追いついた状態へ");
                            return new StateStuckUp();
                        }
                        else
                        {
                            //print("顔をひょっこり出す");
                            //return new StateToHaveFace();
                        }
                    }
                }
                else
                {
                    hideFg = false;
                }

                return null;
            }
        }

        //移動
        class StateFindMove : StateFind
        {
            private float speedLook;
            float speedNotLook;
			AudioSource walk;
			float dist;
            Vector3 dir;
            Camera camera;
            bool hitTree;
            public override void Enter(GameObject enemy)
            {
                speedLook = enemy.GetComponent<EnemyStateScript4>().speedApproach;
                speedNotLook = enemy.GetComponent<EnemyStateScript4>().speedApproachNotLook;
                player = enemy.GetComponent<Enemy2Script>().player;
                camera = enemy.GetComponent<EnemyStateScript4>().camera;

				walk = enemy.GetComponent<EnemyStateScript4>().walk;

				//プレイヤーの方へ向く
				float angle = TargetToFace(enemy.transform.position, player.transform.position);
                enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, angle, enemy.transform.localEulerAngles.z);
                dist = Vector3.Distance(player.transform.position, enemy.transform.position);
                dir = new Vector3(Mathf.Sin(enemy.transform.localEulerAngles.y * Mathf.PI / 180.0f), 0.0f, Mathf.Cos(enemy.transform.localEulerAngles.y * Mathf.PI / 180.0f));
                dir.Normalize();
            }
            public override State DecisionMaking(GameObject enemy)
            {
                //Ray ray = new Ray(enemy.transform.position, dir);
                //RaycastHit[] hit;
                //hit = Physics.RaycastAll(ray, 100.0f);
                ////近い順にソート
                //if (hit.Length != 0)
                //{
                //    for (int i = 0; i < hit.Length - 1; i++)
                //    {
                //        for (int j = i; j < hit.Length; j++)
                //        {
                //            if ((hit[i].collider.gameObject.transform.position - enemy.transform.position).magnitude > (hit[j].collider.gameObject.transform.position - enemy.transform.position).magnitude)
                //            {
                //                RaycastHit comp;
                //                comp = hit[i];
                //                hit[i] = hit[j];
                //                hit[j] = comp;
                //            }
                //        }
                //    }

                //    for (int i = 0; i < hit.Length; i++)
                //    {
                //        if (hit[i].collider.gameObject.tag == "Tree")
                //        {
                //            if (Vector3.Distance(enemy.transform.position, hit[i].transform.position) <= 4.0f)
                //            {
                //                //return new StateAvoidTree();
                //                return new StateWaitTree(hit[i].transform.position);
                //            }
                //        }
                //    }
                //}
                if(hitTree)
                {
                    //return new StateWaitTree2();
                }

                if (hideFg)
                {
                    //print("見失う");
                    //return new StateFindNotFind();

                    //プレイヤーがこちらのほうを向いていたら
                    Vector3 v = enemy.transform.position - player.transform.position;
                    v.y = 0.0f;
                    Vector3 dirPlayer = new Vector3(Mathf.Sin(player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(player.transform.localEulerAngles.y * 0.01745f));
                    float dist = Vector2.Distance(new Vector2(enemy.transform.position.x, enemy.transform.position.z), new Vector2(player.transform.position.x, player.transform.position.z));
                    //print(Vector3.Dot(v.normalized, dirPlayer.normalized));
                    if (Vector3.Dot(v.normalized, dirPlayer.normalized) > 0.93969f && dist < camera.farClipPlane)
                    {
                        enemy.GetComponent<Enemy2Script>().ChangeState(new StateGoFar());
                    }
                }
                else
                {
                    hideFg = false;
                }

                return null;
            }
            public override void Method(GameObject enemy)
            {
                //移動
                //Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
                //Vector3 v = new Vector3(posPlayer.x - enemy.transform.position.x, 0.0f, posPlayer.z - enemy.transform.position.z);
                //v.Normalize();
                //enemy.transform.position += v * speed * Time.deltaTime;

                float speed;
                if (Vector3.Distance(enemy.transform.position, player.transform.position) < camera.farClipPlane) speed = speedLook;
                else speed = speedNotLook;

                if (Vector3.Distance(player.transform.position, enemy.transform.position) > 3.0f)
                {
                    dist -= speed * Time.deltaTime;
                    enemy.transform.position = new Vector3(player.transform.position.x, enemy.transform.position.y, player.transform.position.z) + -dir * dist;
                }
				//if (Vector3.Distance(player.transform.position, enemy.transform.position) <= 12.0f)
				//{
				//	walk.mute = false;
				//}
				//else
					walk.mute = true;
			}
            //public override void OnTriggerEnter(GameObject enemy, Collider collider)
            //{
            //    print("呼び出されマイｓ他");
            //    if(collider.gameObject.tag == "Tree")
            //    {
            //        hitTree = true;
            //    }
            //}
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //追いついた状態
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public class StateStuckUp : StateScript.State
        {
            public override void Enter(GameObject enemy)
            {
                state = new StateStuckUpWait();
                state.Enter(enemy);
            }
            public override State DecisionMaking(GameObject enemy)
            {
                return null;
            }
        }

        //待機
        public class StateStuckUpWait : StateStuckUp
        {
            public override void Enter(GameObject enemy)
            {
                print("生成されました");
            }
            public override State DecisionMaking(GameObject enemy)
            {
                if (hideFg == false)
                {
                    Vector3 v = enemy.transform.position - enemy.GetComponent<Enemy2Script>().player.transform.position;
                    Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
                    print(Vector3.Dot(v.normalized, dirPlayer.normalized));
                    // if (Vector3.Dot(v.normalized, dirPlayer.normalized) > 0.707f)
                    {
                        print("GAME OVERへ");
                        return new StateStuckGameOver();
                    }
                }
                else
                {
                    hideFg = false;
                }
                return null;
            }
            public override void Method(GameObject enemy)
            {
                //if(hideFg)
                {
                    //位置をプレイヤーの目の前へ
                    //Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
                    //Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
                    //posPlayer.y = 0;
                    //Vector3 v = posPlayer - enemy.transform.position;
                    ////enemy.transform.position = enemy.transform.position + -v.normalized * enemy.GetComponent<Enemy2Script>().GetDeadDist();
                    ////プレイヤーの方へ向く
                    //float rad = Mathf.Acos(Vector3.Dot(v.normalized, Vector3.forward));
                    //if (Vector3.Cross(v.normalized, Vector3.forward).y > 0.0f) rad = -rad;
                    //enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, rad * 180.0f / Mathf.PI, enemy.transform.localEulerAngles.z);
                    //float angle = TargetToFace(enemy.transform.position, posPlayer);
                    //enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, angle, enemy.transform.localEulerAngles.z);
                }
                //else if(enemy.GetComponent<Enemy2Script>().pointLight.GetComponent<BatteryScript>().battery <= 0.0f)
                //{
                //    //位置をプレイヤーの目の前へ
                //    Vector3 dirPlayer = new Vector3(Mathf.Sin(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.GetComponent<Enemy2Script>().player.transform.localEulerAngles.y * 0.01745f));
                //    Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
                //    enemy.transform.position = posPlayer + dirPlayer.normalized * 3.0f;
                //    //プレイヤーの方へ向く
                //    Vector3 v = posPlayer - enemy.transform.position;
                //    float rad = Mathf.Acos(Vector3.Dot(v.normalized, Vector3.forward));
                //    if (Vector3.Cross(v.normalized, Vector3.forward).y > 0.0f) rad = -rad;
                //    enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, rad * 180.0f / Mathf.PI, enemy.transform.localEulerAngles.z);
                //}
                //else
                //{
                //    //常にプレイヤーの前で待機
                //    Vector3 posPlayer = enemy.GetComponent<Enemy2Script>().player.transform.position;
                //    Vector3 v = enemy.transform.position - posPlayer;
                //    enemy.transform.position = posPlayer + v.normalized * 3.0f;
                //}
            }
        }

        //GAMEOVER
        public class StateStuckGameOver : StateStuckUp
        {
            public override void Enter(GameObject enemy)
            {
                GameManagerScript gms = enemy.GetComponent<Enemy2Script>().gameManager.GetComponent<GameManagerScript>();
                if (gms.GetState() == GameManagerScript.STATE.PLAY)
                {
                    //Singleton<SoundManagerScript>.instance.PlaySE("se_shout", gms.gameObject);
                    foreach (Transform child in enemy.transform)
                    {
                        child.gameObject.layer = LayerMask.NameToLayer("Water");
                    }
                    //enemy.GetComponent<EnemyStateScript4>().spotLight.enabled = true;
                    //enemy.GetComponent<Enemy2Script>().pointLight.enabled = false;
                    enemy.GetComponent<Enemy2Script>().SetGameOver(true);
                    //enemy.transform.position += Vector3.down;
                    //enemy.transform.localScale += Vector3.one;
                }
            }
            public override State DecisionMaking(GameObject enemy)
            {
                return null;
            }
            public override void Method(GameObject enemy)
            {

            }
        }

        //*************************************************************************************************************************************************
        //
        //*************************************************************************************************************************************************
        //遠ざかっていく
        class StateGoFar : StateScript.State
        {
            Vector3 dir;
            float speed;
            float speedAddMax;
            float speedTimeMax;
            float speedAddTimeStart;
            float speedExponent;
			AudioSource walk;

			Vector3 vecStateNear;
            float dist;
            float time;
            public override void Enter(GameObject enemy)
            {
				walk = enemy.GetComponent<EnemyStateScript4>().walk;
				walk.mute = false;

				player = enemy.GetComponent<Enemy2Script>().player;
                speed = enemy.GetComponent<EnemyStateScript4>().speedLeave;
                speedAddMax = enemy.GetComponent<EnemyStateScript4>().speedLeaveAddMax;
                speedTimeMax = enemy.GetComponent<EnemyStateScript4>().speedLeaveTimeMax;
                speedAddTimeStart = enemy.GetComponent<EnemyStateScript4>().speedLeaveAddTimeStart;
                speedExponent = enemy.GetComponent<EnemyStateScript4>().speedLeaveExponent;
				//speed = 3.0f;
				dir = -new Vector3(Mathf.Sin(enemy.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.transform.localEulerAngles.y * 0.01745f));
                dir.Normalize();
                dist = Vector3.Distance(enemy.transform.position, player.transform.position);

                float angle = TargetBackFace(enemy.transform.position, player.transform.position);
                enemy.transform.localEulerAngles = new Vector3(enemy.transform.localEulerAngles.x, angle, enemy.transform.localEulerAngles.z);

                //dir = enemy.transform.position - player.transform.position;
                //dir.y = 0.0f;
                //dir.Normalize();
                //if (Vector3.Dot(Vector3.right, dir) > 0.0f)
                //{
                //    dir = new Vector3(Mathf.Sin(0.7854f), 0.0f, Mathf.Cos(0.7854f));
                //}
                //else
                //{
                //    dir = new Vector3(Mathf.Sin(-0.7854f), 0.0f, Mathf.Cos(0.7854f));
                //}
                time = Time.time;
                hideFg = true;
            }
            public override State DecisionMaking(GameObject enemy)
            {
                if (hideFg == false)
                {
                    print("追いかける");
                    //return new StateFind();
                    return new StateWait(Mathf.Min(Mathf.Pow((Time.time - time), 2) * 0.167f, 6.0f));
                }
                else
                {
                    hideFg = false;
                }

                return null;
            }
            public override void Method(GameObject enemy)
            {
                //float correction = (Time.time - time) * 0.3f + 1;
                //dist += speed * Time.deltaTime * correction;
                //enemy.transform.position = new Vector3(player.transform.position.x, enemy.transform.position.y, player.transform.position.z) + dir * dist;
                ////enemy.transform.position += dir * speed * Time.deltaTime;

                int t = (int)(Time.time - time);
                if (t < speedAddTimeStart)
                {
                    t = 0;
                }
                float speedAdd = Mathf.Pow(Mathf.Min((t / speedTimeMax), 1), speedExponent) * speedAddMax * Time.deltaTime;
                dist += speed * Time.deltaTime + speedAdd;
                enemy.transform.position = new Vector3(player.transform.position.x, enemy.transform.position.y, player.transform.position.z) + dir * dist;
				//enemy.transform.position += dir * speed * Time.deltaTime;

			}
        }

        class StateWait : StateScript.State
        {
            float waitTime;
            float time;
            public StateWait(float time)
            {
                waitTime = time;
            }
            public override void Enter(GameObject enemy)
            {
                time = Time.time;
            }
            public override State DecisionMaking(GameObject enemy)
            {
                if (Time.time >= time + waitTime)
                {
                    return new StateFind();
                }
                return null;
            }
        }

        class StateAvoidTree : StateScript.State
        {
            float slope;
            float nextSlope;
            Vector3 offsetAngle;
            public override void Enter(GameObject enemy)
            {
                print("木を避けるんじゃ～");
                slope = -45.0f;
                nextSlope = -slope;
                offsetAngle = enemy.transform.localEulerAngles;
                enemy.transform.localEulerAngles = offsetAngle + new Vector3(0.0f, slope, 0.0f);
            }
            public override State DecisionMaking(GameObject enemy)
            {
                if (slope < nextSlope + 0.5f && slope > nextSlope + -0.5f)
                {
                    return new StateFind();
                }
                return null;
            }
            public override void Method(GameObject enemy)
            {
                if (slope > nextSlope + 0.5 || slope < nextSlope + -0.5)
                {
                    slope += 15 * Time.deltaTime;
                }
                enemy.transform.localEulerAngles = offsetAngle + new Vector3(0.0f, slope, 0.0f);
                Vector3 dir = new Vector3(Mathf.Sin(enemy.transform.localEulerAngles.y * 0.01745f), 0.0f, Mathf.Cos(enemy.transform.localEulerAngles.y * 0.01745f));
                enemy.transform.position += dir.normalized * Time.deltaTime;
            }
        }

        //木が通り過ぎるのを待つ
        class StateWaitTree : StateScript.State
        {
            Vector3 target;
            public StateWaitTree(Vector3 _target)
            {
                target = _target;
            }
            public override void Enter(GameObject enemy)
            {
                print("待つんじゃ～");
                player = enemy.GetComponent<Enemy2Script>().player;
            }
            public override State DecisionMaking(GameObject enemy)
            {
                if (Vector3.Dot((target - enemy.transform.position).normalized, Vector3.back) > 0.707f)
                {
                    return new StateFind();
                }
                return null;
            }
        }

        //木が通り過ぎるのを待つ
        //class StateWaitTree2 : StateScript.State
        //{
        //    bool hitTree;
        //    public override void Enter(GameObject enemy)
        //    {
        //        print("待つんじゃ～");
        //        player = enemy.GetComponent<Enemy2Script>().player;
        //        hitTree = true;
        //    }
        //    public override State DecisionMaking(GameObject enemy)
        //    {
        //        if (hitTree == false)
        //        {
        //            return new StateFind();
        //        }
        //        return null;
        //    }
        //    public override void OnTriggerExit(GameObject enemy, Collider collider)
        //    {
        //        if(collider.gameObject.tag == "Tree")
        //        {
        //            hitTree = false;
        //        }
        //    }
        //}
    }
}