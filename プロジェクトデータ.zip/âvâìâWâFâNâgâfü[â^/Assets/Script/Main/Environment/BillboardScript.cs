﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace main
{
	[ExecuteInEditMode]
	public class BillboardScript : MonoBehaviour
	{
		/*ビルボードの対象となるカメラ*/
		[SerializeField]
		Camera target;
		/*縦方向回転制御*/
		[SerializeField]
		bool isVerticalRotation = true;

		void Start()
		{
			if (target == null) target = Camera.main;
		}

		void Update()
		{
			if (isVerticalRotation)
			{
				transform.LookAt(target.transform.position);
			}
			else
			{
				Vector3 t = target.transform.position;
				t.y = transform.position.y;
				transform.LookAt(t);
			}
		}
	}
}
