﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace main
{
	public class MoveStageScript : MonoBehaviour
	{
		[SerializeField]
		GameManagerScript GameManagerScript;

		[SerializeField]
		TouchScript touchScript;

		[SerializeField]
		float speed;

		void Update()
		{
			if(GameManagerScript.GetState()== GameManagerScript.STATE.PLAY|| GameManagerScript.GetState() == GameManagerScript.STATE.SHORT_TUTORIAL)
			{
				if (!touchScript.IsPray())
				{
					transform.Translate(0, 0, -speed * Time.deltaTime);

					if (transform.position.z < -40)
					{
						transform.Translate(0, 0, 80, Space.World);
					}
				}
			}
		}
	}
}
