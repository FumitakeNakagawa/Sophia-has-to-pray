﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace main
{
    public class GameStateScript : MonoBehaviour
    {

        [SerializeField]
        GameObject GameClear, GameOver;

        [SerializeField]
        FadeScript fadeScript;

        [SerializeField]
        GameManagerScript GameManager;


        float startTime;
        float goalTime;

        private GUIStyle label;

        [SerializeField]
        WhiteOutScript WhiteOutScript;

		bool clear;

        void Start()
        {
            startTime = Time.time;
            label = new GUIStyle();
            label.fontSize = Screen.height / 50;
            label.normal.textColor = Color.white;

			GameClear.SetActive(false);
			GameOver.SetActive(false);

			//GameManager = GetComponent<GameManagerScript>();
			clear = false;
        }

        // Update is called once per frame
        void Update()
        {
            if (fadeScript.IsFadeEnd())
            {

                if (GameManager.GetState() == GameManagerScript.STATE.GAME_OVER)
                {
					GameOver.SetActive(true);
                }
                if (GameManager.GetState() == GameManagerScript.STATE.CLEAR)
                {
                    if (WhiteOutScript.GetWhiteOutEndFg())
                    {
                        if (!clear)
                        {
							Singleton<SoundManagerScript>.instance.PlayBGM("bgm_end", 5, true);
							goalTime = Time.time;
							GameClear.SetActive(true);
							clear = true;
                        }
                    }
                }

            }
        }

        void OnGUI()
        {
            string text = string.Empty;
            text = string.Format("ゴールタイム : " + (goalTime - startTime));

            //GUI.Label(new Rect(500, 0, 400, 400), text, label);
        }
    }
}