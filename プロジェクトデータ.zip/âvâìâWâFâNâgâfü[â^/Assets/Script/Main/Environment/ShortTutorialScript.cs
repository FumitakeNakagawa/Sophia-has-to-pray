﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace main
{

    public class ShortTutorialScript : MonoBehaviour
    {
        bool tutorialEnd;
        public bool IsTutorialEnd() { return tutorialEnd; }

        [SerializeField]
        GameObject tutorialEnemy;
        Enemy2Script enemy2Script;
        EnemyStateScript5 enemySatate;

        [System.Serializable]
        public struct Player
        {
            public GameObject obj;

            [HideInInspector]
            public PlayerScript playerScript;
            [HideInInspector]
            public SwipeScript swipeScript;
        }

        [SerializeField]
        Player player;
        public Player GetPlayer() { return player; }

        [SerializeField]
        GameObject canvas;

        ShortTutorialCanvas shortTutorialCanvasScript;
        bool teachEnd;
        bool LookBackEnd;
        bool LookFrontEnd;
        bool goback;
        // Use this for initialization
        void Start()
        {
            enemy2Script = tutorialEnemy.GetComponent<Enemy2Script>();
            enemySatate = tutorialEnemy.GetComponent<EnemyStateScript5>();
            player.playerScript = player.obj.GetComponent<PlayerScript>();
            player.swipeScript = player.obj.GetComponent<SwipeScript>();
            player.playerScript.enabled = true;
            tutorialEnd = false;
            LookBackEnd = false;
            LookFrontEnd = false;
            teachEnd = false;
            goback = false;
            shortTutorialCanvasScript = canvas.GetComponent<ShortTutorialCanvas>();
        }

        // Update is called once per frame
        void Update()
        {
            if (!teachEnd && shortTutorialCanvasScript.IsTeachEnd())
            {
                player.swipeScript.enabled = true;
                //enemy2Script.enabled = false;
                teachEnd = true;
            }



            if (!LookBackEnd && player.swipeScript.GetNowIndex() == SwipeScript.DIRECT.DOWN)
            {
                enemy2Script.enabled = true;
                LookBackEnd = true;
                shortTutorialCanvasScript.SetLookBackEnd(true);
				player.swipeScript.enabled = false;
            }
            else if (!goback&&shortTutorialCanvasScript.IsGoback())
            {
                enemy2Script.enabled = true;
                enemySatate.enabled = true;
                //StartCoroutine(enemy2Script.Message("hide"));
                goback = true;
            }
            else if(LookBackEnd&&!LookFrontEnd&&player.swipeScript.GetNowIndex() == SwipeScript.DIRECT.CENTER)
            {
                LookFrontEnd = true;
                shortTutorialCanvasScript.SetLookFrontEnd(true);

            }

            if (shortTutorialCanvasScript.IsStart())
                TutorialEnd();
        }


        public void TutorialEnd()
        {
            //player.swipeScript.SetNextIndex(SwipeScript.DIRECT.CENTER);
            tutorialEnd = true;
            Destroy(gameObject);

        }
    }
}