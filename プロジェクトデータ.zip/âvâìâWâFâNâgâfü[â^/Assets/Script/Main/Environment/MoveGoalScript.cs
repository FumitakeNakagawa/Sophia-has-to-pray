﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace main
{
	public class MoveGoalScript : MonoBehaviour
	{
		[SerializeField]
		GameManagerScript GameManagerScript;

		[SerializeField]
		TouchScript touchScript;

		[SerializeField]
		float speed;

		[SerializeField, Header("ゴールの位置(Z座標)")]
		float dist;

		void Start()
		{
			transform.position = new Vector3(0, 0, dist);
		}

		void Update()
		{
			if(GameManagerScript.GetState() != GameManagerScript.STATE.SHORT_TUTORIAL)
			{
				if (GameManagerScript.GetState() == GameManagerScript.STATE.PLAY)
				{
					if (!touchScript.IsPray())
					{
						transform.Translate(0, 0, -speed * Time.deltaTime, Space.World);
					}
				}
			}
		}
	}
}
