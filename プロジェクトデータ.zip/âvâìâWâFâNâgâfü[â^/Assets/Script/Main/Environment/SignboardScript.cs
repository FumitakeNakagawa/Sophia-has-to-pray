﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace main
{
	public class SignboardScript : MonoBehaviour
	{
		enum POINT : int
		{
			FIRST_POINT = 1,
			SECOND_POINT,
			THIRD_POINT,
			GOAL_POINT
		};

		[SerializeField]
		GameManagerScript GameManagerScript;

		[SerializeField]
		TouchScript touchScript;

		[SerializeField]
		SwipeScript swipeScript;

		//プレイヤーの場所
		[SerializeField]
		Transform PlayerPosition;

		//ゴール地点
		[SerializeField]
		Transform GoalPosition;

		[SerializeField]
		Material mat;

		[SerializeField]
		float speed;

		//最大距離
		float MaxDist;

		float dist;

		int[] cut = new int[5];

		int nowIndex;

		void Start()
		{
			MaxDist = Vector3.Distance(GoalPosition.position, PlayerPosition.position);

			float per = (int)100 / (cut.Length - 1);
			for (int index = 0; index < cut.Length; index++)
			{
				cut[index] = (int)per * index;
			}
			nowIndex = (int)POINT.FIRST_POINT;
			cut[cut.Length - 1] -= 2;

			dist = MaxDist * (cut[nowIndex] * 0.01f);
			transform.position = new Vector3(-2.0f, 0, dist + 10.0f);

			mat.SetTextureOffset("_MainTex", new Vector2(0, 0));
		}

		void Update()
		{
			if (GameManagerScript.GetState() == GameManagerScript.STATE.PLAY)
			{
				if (!touchScript.IsPray())
				{
					transform.Translate(0, 0, -speed * Time.deltaTime, Space.World);
				}
				if (swipeScript.GetNowIndex() != SwipeScript.DIRECT.DOWN && swipeScript.GetNowIndex() != SwipeScript.DIRECT.CENTER&& cut.Length > nowIndex)
				{
					if (PlayerPosition.position.z - 1 > transform.position.z)
					{
						float nowDist = Vector3.Distance(GoalPosition.position, PlayerPosition.position);
						nowIndex++;
						if (nowIndex == (int)POINT.GOAL_POINT) nowIndex--;
						dist = MaxDist * (cut[nowIndex] * 0.01f) - (MaxDist - nowDist);
						transform.position = new Vector3(-2.0f, 0, dist+10.0f);
					}
					switch (nowIndex)
					{
						case (int)POINT.FIRST_POINT:
							mat.SetTextureOffset("_MainTex", new Vector2(0, 0));
							break;
						case (int)POINT.SECOND_POINT:
							mat.SetTextureOffset("_MainTex", new Vector2(0.5f, 0));
							break;
						case (int)POINT.THIRD_POINT:
							mat.SetTextureOffset("_MainTex", new Vector2(0, 0.5f));
							break;
						case (int)POINT.GOAL_POINT:
							mat.SetTextureOffset("_MainTex", new Vector2(0.5f, 0.5f));
							break;
					}
				}
			}
		}
	}
}
