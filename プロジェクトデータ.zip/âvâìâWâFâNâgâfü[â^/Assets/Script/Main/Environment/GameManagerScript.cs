﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace main
{
	public class GameManagerScript : MonoBehaviour
	{
		//難易度
		public enum DIFFICULTY
		{
			EASY,
			NORMAL,
			HARD,
			TUTORIAL,
		}

		//エネミー(子)の管理
		[System.Serializable]
		struct s_Enemy
		{

			//[HideInInspector]
			public GameObject gameObject;
			//[HideInInspector]
			public bool GameOverFlg;
			public main.Enemy2Script enemy2Script;
			//アニメーター
			public EnemyAnimatorScript animator;
		}

		//ステート
		public enum STATE
		{
			STANDBY,
			SHORT_TUTORIAL,
			PLAY,
			CLEAR,
			SLERP,
			GAME_OVER
		}


		//ステート
		public STATE state;

		//難易度選択
		[SerializeField]
		DIFFICULTY difficulty;

		[SerializeField]
		Transform GoalPoint;

		[System.Serializable]
		struct Player
		{
			[SerializeField]
			public GameObject playerObj;
			[SerializeField]
			public GameObject lampObj;

			public main.TouchScript touchScript;
			public main.SwipeScript swipeScript;
			public main.PlayerScript playerScript;

			public main.LightScript lightScript;
		}
		[Space, SerializeField]
		Player player;

		[SerializeField]
		GameObject lamp;

		[SerializeField]
		LightScript lightScript;

		[SerializeField]
		main.FadeScript fadeScript;

		//敵まとめてるオブジェクト
		[Space, SerializeField]
		public GameObject Enemy;
		//敵単体オブジェクト
		[SerializeField]
		s_Enemy[] enemies;

		[Space, Space]
		[SerializeField]
		GameObject Pinch;

		public int frameCount;
		private int frameDraw;      //描画用
		public float nextTime;
		private GUIStyle labelFPS;
		float timeEnvironment;          //環境音のなる間隔

		public Quaternion DeadRotation;
		int DeadIndex;
		float t;
		float handSpeed;
		float speedUp;

		[SerializeField]
		bool isShortTutorial;

		[SerializeField]
		GameObject Signboard;

		[SerializeField]
		GameObject Shout;

		[System.Serializable]
		struct DifficultySetting
		{
			public main.EnemyStateScript4 enemyStateScript4;

			public float maxCandle;

			[Header("位置")]
			public Vector3[] position;
			[Header("速度")]
			public float[] speedApproach;
			[Header("退避速度")]
			public float[] speedLeave;
		}

		[SerializeField, Header("難易度別設定")]
		DifficultySetting[] difficultySetting;

		public STATE GetState() { return state; }
		public void SetState(STATE s) { state = s; }


		public DIFFICULTY GetDifficulty() { return difficulty; }

		ShortTutorialScript shortTutorialScript;
		[SerializeField]
		GameObject shortTutorial;

		static bool HardFirstExecute = true;

		// Use this for initialization
		void Start()
		{
			Singleton<SoundManagerScript>.instance.UnMuteSound();
			Singleton<SoundManagerScript>.instance.PlayBGM("bgm_main", 0.0f, true);
			timeEnvironment = 6.0f;
			frameCount = 0;
			nextTime = Time.time + 1;

			labelFPS = new GUIStyle();
			labelFPS.fontSize = Screen.height / 50;
			labelFPS.normal.textColor = Color.white;
			frameDraw = 0;

			state = STATE.STANDBY;

			player.swipeScript = player.playerObj.GetComponent<SwipeScript>();
			player.playerScript = player.playerObj.GetComponent<PlayerScript>();
			player.touchScript = player.playerObj.GetComponent<TouchScript>();

			t = 0;
			handSpeed = 0;
			speedUp = 0;

			DeadRotation = new Quaternion(0, 0, 0, 1);

			if (HardFirstExecute)
				isShortTutorial = true;
			else
				isShortTutorial = false;

			shortTutorial.SetActive(false);
			//if (difficulty != DIFFICULTY.HARD)
			//{
			//	enemies[enemies.Length - 1].gameObject.SetActive(false);
			//}

			shortTutorialScript = shortTutorial.GetComponent<ShortTutorialScript>();
		}

		void Update()
		{
			Singleton<SoundManagerScript>.instance.Update();

			switch (state)
			{
				case STATE.STANDBY:
					if (fadeScript.IsStartFadeEnd())
					{
						ScriptEnabled(false);
						if (HardFirstExecute && difficulty == DIFFICULTY.HARD)
						{
							state = STATE.SHORT_TUTORIAL;
							shortTutorial.SetActive(true);
							if (HardFirstExecute)
								HardFirstExecute = false;
						}
						else
						{
							state = STATE.PLAY;
							ScriptEnabled(true);
						}

					}

					break;
				case STATE.SHORT_TUTORIAL:
					if (shortTutorialScript.IsTutorialEnd())
						isShortTutorial = false;
					if (!isShortTutorial)
					{
						ScriptEnabled(true);
						Signboard.SetActive(true);

						state = STATE.PLAY;
					}
					break;
				case STATE.PLAY:
					for (int index = 0; index < enemies.Length; index++)
					{
						enemies[index].GameOverFlg = enemies[index].gameObject.GetComponent<main.Enemy2Script>().isGameOver();
						if (enemies[index].GameOverFlg)
						{
							if (player.swipeScript.GetNowIndex() == SwipeScript.DIRECT.CENTER && index == 0)
								t = 0.8f;
							else if (player.swipeScript.GetNowIndex() == SwipeScript.DIRECT.LEFT && index == 1)
								t = 0.8f;
							else if (player.swipeScript.GetNowIndex() == SwipeScript.DIRECT.RIGHT && index == 2)
								t = 0.8f;
							else if (player.swipeScript.GetNowIndex() == SwipeScript.DIRECT.DOWN && index == 3)
								t = 0.8f;


							enemies[index].gameObject.transform.rotation = Quaternion.LookRotation(player.playerObj.transform.position - (enemies[index].gameObject.transform.position + new Vector3(0, player.playerObj.transform.position.y, 0)));

							DeadRotation = player.playerObj.transform.rotation;
							DeadIndex = index;
							state = STATE.SLERP;

							Pinch.SetActive(false);
							player.playerScript.enabled = false;
							break;
						}
					}

					Goal();
					break;
				case STATE.SLERP:
					player.lightScript.FadeCandle();
					speedUp += 0.03f;
					t += speedUp * Time.deltaTime;
					//t = Mathf.Min(1, t);
					//t = Mathf.Max(t, 0);
					if (t >= 1)
					{
						player.lightScript.ZeroCandle();
						Singleton<SoundManagerScript>.instance.MuteSound();
						Singleton<SoundManagerScript>.instance.PlaySE("se_fearend", gameObject);
						Singleton<SoundManagerScript>.instance.PlaySE("se_shout", Shout);
						enemies[DeadIndex].enemy2Script.spotLight.enabled = true;
						state = STATE.GAME_OVER;
					}
					break;
				case STATE.GAME_OVER:
					enemies[DeadIndex].animator.TriggerGameOverFlg();
					break;
				case STATE.CLEAR:
					print(state);
					//player.playerScript.enabled = false;
					Pinch.SetActive(false);
					CheckUP();
					break;
			}

			if (state >= STATE.SLERP)
			{
				if (handSpeed < 1)
				{
					player.playerObj.transform.rotation = Quaternion.Slerp(player.playerObj.transform.rotation, Quaternion.LookRotation((enemies[DeadIndex].gameObject.transform.position + new Vector3(0, player.playerObj.transform.position.y, 0)) - player.playerObj.transform.position), t);

					handSpeed += speedUp * Time.deltaTime;
					lamp.transform.Translate(handSpeed, -handSpeed, 0);
				}
				else lamp.SetActive(false);
			}

			//Debug.Log(enemies[1].gameObject.transform.position.ToString());

			//SE
			PlaySE(gameObject, "Beats", "se_beats");


			//フレームレート
			frameCount++;
			if (Time.time >= nextTime)
			{
				// 1秒経ったらFPSを表示
				//Debug.Log("FPS : " + frameCount);
				//frameCount = 0;
				//nextTime += 1;
			}


		}

		void CheckUP()
		{
			switch (difficulty)
			{
				case DIFFICULTY.TUTORIAL:

					break;
				case DIFFICULTY.EASY:
					Title.Title.difficult[0].state = Title.Title.Difficult.STATE.CLEAR;
					break;
				case DIFFICULTY.NORMAL:
					Title.Title.difficult[1].state = Title.Title.Difficult.STATE.CLEAR;
					break;
				case DIFFICULTY.HARD:
                    Title.Title.difficult[2].state = Title.Title.Difficult.STATE.CLEAR;

                    break;
			}
		}

		void Goal()
		{
			if (player.playerObj.transform.position.z >= GoalPoint.position.z)
			{
				Singleton<SoundManagerScript>.instance.MuteSound();
				state = STATE.CLEAR;
			}
		}

		void PlaySE(GameObject gameManager, string nameObj, string nameSE)

		{
			GameObject se = null;
			foreach (Transform child in gameManager.transform)
			{
				if (child.name == nameObj)
				{
					se = child.gameObject;
					break;
				}
			}
			if (se == null) return;
			if (player.touchScript.IsPray())
			{
				if (se.GetComponent<AudioSource>().pitch < 1.4f) se.GetComponent<AudioSource>().pitch += 0.0002f;
				Singleton<SoundManagerScript>.instance.PlaySE(nameSE, se);
			}
			else
			{
				se.GetComponent<AudioSource>().pitch = 1.0f;
			}
		}

		//void OnGUI()
		//{
		//    if (Time.time >= nextTime)
		//    {
		//        // 1秒経ったらFPSを表示
		//        string text = string.Empty;
		//        text = string.Format("FPS : " + frameCount);

		//        //GUI.Label(new Rect(0, 0, 200, 200), text, labelFPS);

		//        frameDraw = frameCount;
		//        frameCount = 0;
		//        nextTime += 1;
		//    }
		//    else
		//    {
		//        string text = string.Empty;
		//        text = string.Format("FPS : " + frameDraw);

		//        GUI.Label(new Rect(0, 60, 200, 200), text, labelFPS);
		//    }

		//    string str = SceneManager.GetActiveScene().name;
		//    GUI.Label(new Rect(0, 0, 400, 400), str, labelFPS);
		//}



		private void ScriptEnabled(bool val)
		{
			player.touchScript.enabled = val;
			player.swipeScript.enabled = val;
			player.lightScript.enabled = val;
			foreach (var it in enemies)
				it.enemy2Script.enabled = val;
		}
	}
}