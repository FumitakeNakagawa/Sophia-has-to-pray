﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using main;

[ExecuteInEditMode]

public class WhiteOutScript : MonoBehaviour
{

    //マテリアル
    [SerializeField]
    Material mat = null;
    //口径食
    [SerializeField]
    Shader WhiteOut;

    float rate;
    bool WhiteOutFg;
    bool WhiteOutEndFg;
    float time;
    //ホワイトアウトする時間(s)
    [SerializeField]
    float WhiteOutTime;
    [SerializeField]
    GameManagerScript GameManagerScript;

    [SerializeField]
    GameObject Gleam;

    void Start()
    {
        mat = GetComponent<Image>().material;
        WhiteOut = mat.shader;
        if (GetComponent<Image>().enabled == true)
        {
            GetComponent<Image>().enabled = false;
        }
    }

    void Update()
    {
        if (WhiteOutFg)
        {
            if (Time.time < time + WhiteOutTime)
            {
                rate = (Time.time - time) / WhiteOutTime;
            }
            else
            {
                rate = 1.0f;
                WhiteOutEndFg = true;
            }

            if (GetComponent<Image>().enabled == false)
            {
                GetComponent<Image>().enabled = true;
            }
        }
        else
        {
            if (GameManagerScript.GetState() == GameManagerScript.STATE.CLEAR && WhiteOutTime != 0)
            {
                Singleton<SoundManagerScript>.instance.PlaySE("se_gleam", Gleam);
                WhiteOutFg = true;
                time = Time.time;
            }
        }

        mat.SetFloat("_Rate", rate);
    }

    public bool GetWhiteOutEndFg()
    {
        return WhiteOutEndFg;
    }
}
