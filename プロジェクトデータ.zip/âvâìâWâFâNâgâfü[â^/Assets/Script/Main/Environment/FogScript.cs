﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace main
{
	[ExecuteInEditMode]
	public class FogScript : MonoBehaviour
	{
		//フォグ設定
		[SerializeField]
		bool isFog = true;
		//フォグカラー
		[SerializeField]
		Color color = Color.black;
		//フォグモード
		[SerializeField]
		FogMode mode = FogMode.Exponential;
		//フォグがかかり始める距離
		[SerializeField]
		float start = 0.0f;
		//見えなくなる距離
		[SerializeField]
		float end = 30.0f;
		//密度
		[SerializeField]
		float density = 1.0f;

		void Update()
		{
			RenderSettings.fog = isFog;
			RenderSettings.fogColor = color;
			if ((RenderSettings.fogMode = mode) == FogMode.Linear)
			{
				RenderSettings.fogStartDistance = start;
				RenderSettings.fogEndDistance = end;
			}
			else
			{
				RenderSettings.fogDensity = density;
			}
		}

		/*フォグカラーのゲッター*/
		public Color getColor()
		{
			return color;
		}

		/*フォグカラーのセッター*/
		public void setColor(Color color)
		{
			this.color = color;
		}

		/*フォグ密度のセッター*/
		public void setDensity(float density)
		{
			this.density = density;
		}

		/*フォグ密度のセッター*/
		public float getDensity()
		{
			return density;
		}
	}
}