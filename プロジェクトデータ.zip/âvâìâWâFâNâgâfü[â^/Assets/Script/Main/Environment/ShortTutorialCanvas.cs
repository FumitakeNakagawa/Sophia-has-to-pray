﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


namespace main
{
    public class ShortTutorialCanvas : MonoBehaviour
    {

        [SerializeField, Multiline]
        string[] textOffset;
        [SerializeField, Multiline]
        string[] textOffsetLookBack;
        [SerializeField, Multiline]
        string[] textOffsetLookFront;

        [SerializeField]
        Text text;
        int textIndex;

        bool teachEnd;
        public bool IsTeachEnd() { return teachEnd; }

        bool LookBackEnd;
        bool textEnabled;
        public void SetLookBackEnd(bool val) { LookBackEnd = val; }
        public void SetLookFrontEnd(bool val) { lookFrontEnd = val; }
        bool start;
        public bool IsStart() { return start; }
        public bool goback;
        public bool IsGoback() { return goback; }
        public bool lookFrontEnd;
        public bool IsLookFrontEnd() { return lookFrontEnd; }

        [SerializeField]
        GameObject Panel;

        [SerializeField]
        ShortTutorialScript shortTutorial;
        // Use this for initialization
        void Start()
        {
            textIndex = 0;
            text.text = textOffset[textIndex];
            textEnabled = false;
            start = false;
            goback = false;
        }

        // Update is called once per frame
        void Update()
        {
            if (!textEnabled && LookBackEnd)
            {
                text.enabled = true;
                textEnabled = true;
                Panel.SetActive(true);
                textIndex = 0;
            }

            if(lookFrontEnd)
            {
                textIndex = 0;
            }
            if (!LookBackEnd)
                text.text = textOffset[textIndex];
            else if(!lookFrontEnd&&LookBackEnd)
            {
                text.text = textOffsetLookBack[textIndex];
                goback = true;
            }
            else if(lookFrontEnd)
            {
                Panel.SetActive(true);
                text.text = textOffsetLookFront[textIndex];
            }
        }

        public void Next()
        {
            textIndex++;
            if (!LookBackEnd)
            {
                if (textIndex == textOffset.Length-1)
                {
                   // textIndex = 0;
                   // text.enabled = false;
                    Panel.SetActive(false);
                    teachEnd = true;
                }
            }
            else if (!lookFrontEnd&&LookBackEnd)
            {
                if (textIndex == textOffsetLookBack.Length - 1)
                {
					shortTutorial.GetPlayer().swipeScript.enabled = false;
				}
                if (textIndex >= textOffsetLookBack.Length)
                {
                    textIndex = textOffsetLookBack.Length - 1;
					shortTutorial.GetPlayer().swipeScript.enabled = true;
					Panel.SetActive(false);
                    //start = true;
                }
            }
            else if(lookFrontEnd)
            {
				shortTutorial.TutorialEnd();
            }
        }
    }
}
