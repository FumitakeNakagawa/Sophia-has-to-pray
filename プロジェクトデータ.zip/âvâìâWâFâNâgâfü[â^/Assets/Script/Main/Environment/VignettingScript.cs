﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]

public class VignettingScript : MonoBehaviour
{

	//マテリアル
	[SerializeField]
	Material mat = null;
	//口径食
	[SerializeField]
	Shader vignetting;

	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		//無ければマテリアル作成
		if (mat == null)
		{
			mat = new Material(vignetting);
		}

		Graphics.Blit(source, destination, mat);
	}
}
