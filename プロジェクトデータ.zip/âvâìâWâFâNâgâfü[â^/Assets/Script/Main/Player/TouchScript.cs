﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace main
{
    public class TouchScript : MonoBehaviour
    {
        [SerializeField]
        GameObject enemy;

        GameObject[] enemies;

        [SerializeField]
        GameObject GameManager;

        [SerializeField]
        GameObject pray;

        PluginScript plugin;

        GameManagerScript GameManagerScript;

        SwipeScript swipeScript;
        [SerializeField]
        bool isPray;

        void Start()
        {
            isPray = false;

            plugin = GameManager.GetComponent<PluginScript>();
            GameManagerScript = GameManager.GetComponent<GameManagerScript>();
            swipeScript = GetComponent<SwipeScript>();
            enemies = new GameObject[enemy.transform.childCount];
            for (int index = 0; index < enemies.Length; index++)
                enemies[index] = enemy.transform.GetChild(index).gameObject;
        }

        void Update()
        {
            //フレイ中
            if (GameManagerScript.GetState() == GameManagerScript.STATE.PLAY || GameManagerScript.GetState() == GameManagerScript.STATE.SHORT_TUTORIAL || GameManagerScript.GetState() == GameManagerScript.STATE.CLEAR)
            {
                if (swipeScript.IsSlerp()) return;
                    //祈ったら
                    if (plugin.proximityValue == 0 || Input.touchCount > 2 )
                    {
                        if (!isPray)
                        {
                            isPray = true;
                            Singleton<SoundManagerScript>.instance.PlaySE("se_pray", pray);
                        }
                    }
                    else
                    {
                        isPray = false;
                    }

                if (isPray)
                {
                    foreach (var it in enemies)
                    {
                        StartCoroutine(it.GetComponent<Enemy2Script>().Message("hide"));
                    }
                }
            }
            else enabled = false;
        }

        /*祈っているか*/
        public bool IsPray() { return isPray; }
    }
}