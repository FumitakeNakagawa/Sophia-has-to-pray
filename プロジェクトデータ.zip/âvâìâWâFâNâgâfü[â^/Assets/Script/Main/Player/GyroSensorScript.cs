﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace main
{
    public class GyroSensorScript : MonoBehaviour
    {
        Quaternion Rotation;

        Vector3 move;//初期状態からの移動量

        [SerializeField, Range(0.01f, 0.1f)]
        float RoundValue; //丸め(微弱のセンサーの反応防止用)

        [SerializeField, Range(0, 90.0f), Header("向ける限界")]
        float angle;//向ける限界

        [SerializeField, Header("傾く速さ")]
        float power;//傾く速さ

        [Header("___________________________________________")]

        [SerializeField, Header("縦方向ジャイロ有効無効")]
        bool UseAxisXGyro;//縦方向ジャイロ有効無効


        [Header("上下方向の向ける限界角度")]

        [SerializeField, Range(-90, 0)]
        float DownAngle;
        [SerializeField, Range(0, 90)]
        float UpAngle;

        [Header("___________________________________________")]
        [SerializeField, Header("3方向ジャイロ有効･無効")]
        bool Use3WayGyro;

        [SerializeField, Header("球形補間有効･無効")]
        bool UseSlerp;

        [SerializeField, Header("視点切り替えの角度")]
        float SwitchAngle;

        // Use this for initialization
        bool slerp;

        //Slerpの移動量
        float t;

        [SerializeField, Header("球面補間の速さ")]
        float SlerpSpeed;

        //3方向のオフセット角度
        Vector3[] offsetVector = new Vector3[3];
        Quaternion[] offset;

        [SerializeField]
        int nowIndex;//今向いてる視点インデックス
        [SerializeField]
        int nextIndex;//次向く視点インデックス


        bool isSlerp;

        public int GetNowIndex() { return nowIndex; }
        public Quaternion GetOffset(int index) { return offset[index]; }

        void Start()
        {
            Input.gyro.enabled = true;
            Rotation = new Quaternion(0, 0, 0, 1);
            move = new Vector3(0, 0, 0);
            nextIndex = nowIndex = 1;



            offsetVector[0] = new Vector3(0, -angle, 0);
            offsetVector[1] = new Vector3(0, 0, 0);
            offsetVector[2] = new Vector3(0, angle, 0);

            offset = new Quaternion[offsetVector.Length];
            for (int i = 0; i < offsetVector.Length; i++)
            {
                offset[i] = Quaternion.Euler(offsetVector[i]);
            }
            t = 0.0f;

            isSlerp = false;
        }


        // Update is called once per frame
        void Update()
        {
            Vector3 rot = new Vector3(0, 0, 0);
            //ジャイロの値取得
            Vector3 r = Input.gyro.rotationRate;

            //誤差丸め
            if (Mathf.Abs(r.x) < RoundValue) r.x = 0.0f;
            if (Mathf.Abs(r.y) < RoundValue) r.y = 0.0f;
            if (Mathf.Abs(r.z) < RoundValue) r.z = 0.0f;



            //限界突破させないようにしてる
            move += r;
            if (move.x > UpAngle) move.x = UpAngle;
            if (move.x < -angle) move.x = -angle;
            if (move.y > angle) move.y = angle;
            if (move.y < -angle) move.y = -angle;


            rot = move;
            if (rot.x < DownAngle) rot.x = DownAngle;

            if (!isSlerp)
            {
                //縦方向
                if (UseAxisXGyro)
                    Rotation = Quaternion.Euler(-rot.x, -rot.y, 0);
            }


            //3カメラ方向
            if (Use3WayGyro)
            {

                //Slerp使うとき
                if (UseSlerp)
                {
                    Vector3 v = new Vector3(0, 0, 0);
                    //秒速
                    float frame = SlerpSpeed * Time.deltaTime;
                    t += frame;
                    //一定角傾けると視点変更
                    if (rot.y < -SwitchAngle && (!isSlerp))
                    {
                        nextIndex = 2;
                        isSlerp = true;
                    }
                    else if (rot.y > SwitchAngle && (!isSlerp))
                    {
                        nextIndex = 0;
                        isSlerp = true;
                    }
                    else if (!isSlerp)
                    {
                        isSlerp = true;
                        nextIndex = 1;
                    }


                    //傾ききった
                    if (t >= 1.0f)
                    {
                        t = 1.0f;
                        nowIndex = nextIndex;
                        isSlerp = false;
                    }

                    //向く予定の視点と今の視点が同じとき
                    if (nowIndex == nextIndex)
                    {
                        t = 0.0f;
                        isSlerp = false;
                    }

                    Quaternion q1 = offset[nowIndex];
                    Quaternion q2 = offset[nextIndex];

                    //縦方向ジャイロ合成
                    if (UseAxisXGyro)
                    {
                        Quaternion axisX = Quaternion.Euler(-rot.x, 0, 0);
                        q1 *= axisX;
                        q2 *= axisX;
                    }


                    Rotation = Quaternion.Slerp(q1, q2, t);
                }
                //Slerp使わないとき(瞬時に切り替わる)
                else
                {
                    if (rot.y <= -SwitchAngle)
                    {
                        Rotation = Quaternion.Euler(0.0f, angle, 0.0f);
                    }
                    else if (rot.y >= SwitchAngle)
                    {
                        Rotation = Quaternion.Euler(0.0f, -angle, 0.0f);
                    }
                    else
                        Rotation = Quaternion.Euler(0.0f, 0.0f, 0.0f);
                }
            }
            //自由視点
            else
                Rotation = Quaternion.Euler(0, -rot.y, 0) * Quaternion.Euler(-rot.x, 0, 0);
        }


        public Quaternion GetRotation() { return Rotation; }

        public void RefreshSensorValue()
        {
            move = new Vector3(0, 0, 0);
        }

    }
}
