﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace main
{
	public class LightScript : MonoBehaviour
	{
		/*フォグ*/
		[SerializeField]
		List<FogScript> fog;
		/*加速度スクリプト*/
		[SerializeField]
		GameManagerScript GameManagerScript;
		/*加速度スクリプト*/
		[SerializeField]
		LightPowerScript lightPower;
		/*ライト*/
		private new Light light;
		/*ロウソク残量*/
		private float candle;
		/*ロウソク全体*/
		[SerializeField]
		float maxCandle;
		/*ライトの明るさ*/
		[SerializeField]
		float intensity;
		/*ロウソクの消費量*/
		[SerializeField]
		float consumption;
		/*ランタンのマテリアル*/
		[SerializeField]
		Material mat;
		/*Emissionカラー*/
		private Color emissionColor = new Color(5.0f, 0.7f, 0.0f, 1.0f);


		void Start()
		{
			light = gameObject.GetComponent<Light>();
			light.intensity = intensity;

			candle = maxCandle;

			//Emissionカラー設定
			mat.EnableKeyword("_EMISSION");
			mat.SetColor("_EmissionColor", emissionColor);
		}

		void Update()
		{
			if (Expense())
			{
				light.enabled = true;

				//ライト揺らめき
				Color color = light.color;
				color.g = Random.Range(0.40f, 0.50f);
				light.color = color;
				light.intensity += Fluctuation(candle * 100);

				color = emissionColor;
				color.g = Random.Range(0.6f, 0.7f);
				mat.SetColor("_EmissionColor", color);

				lightPower.LightPower(this);
			}
			else
			{
				for (int i = 0; i < fog.Count; i++)
				{
					fog[i].setColor(new Color(0.1f, 0.1f, 0.1f, 1.0f));
					fog[i].setDensity(1.0f);
				}

				light.intensity = 0.0f;
				mat.SetColor("_EmissionColor", Color.black);
				gameObject.transform.parent.gameObject.layer = LayerMask.NameToLayer("Default");
			}
		}

		//ロウソクを消費
		public bool Expense()
		{
			if (GameManagerScript.GetState() == GameManagerScript.STATE.SHORT_TUTORIAL) return true;

			if (candle > 0.0f)
			{
				candle -= consumption * Time.deltaTime;
				return true;
			}
			else candle = 0.0f;

			return false;
		}

		//ロウソク残量割合
		public float Percentage()
		{
			return (candle / maxCandle) * 100;
		}

		//揺らぎ
		float Fluctuation(float x)
		{
			float val = 0.0f;
			for (int i=0;i<=10;i++)
			{
				val += Mathf.Pow(2, -i) * Mathf.Sin(Mathf.Pow(2, i) * x)*0.5f;
			}
			return val;
		}

		public void setConsumption(float consumption)
		{
			this.consumption = consumption;
		}

		public Light getLight()
		{
			return light;
		}

		public List<FogScript> getFog()
		{
			return fog;
		}

		public float getIntensity()
		{
			return intensity;
		}

		public float getConsumption()
		{
			return consumption;
		}

		public void FadeCandle()
		{
			candle -= 0.2f;
		}

		public void ZeroCandle()
		{
			candle = 0.0f;
		}

	}
}