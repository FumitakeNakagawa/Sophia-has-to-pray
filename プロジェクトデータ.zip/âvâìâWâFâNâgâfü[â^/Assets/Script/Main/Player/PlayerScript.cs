﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace main
{
	public class PlayerScript : MonoBehaviour
	{
		private TouchScript touchScript;
		private SwipeScript swipeScript;
		[SerializeField]
		GameObject walk;

		[SerializeField]
		GameManagerScript GameManeger;

		public GameManagerScript GetGameManager() { return GameManeger; }
		// Use this for initialization
		void Start()
		{
			touchScript = GetComponent<TouchScript>();
			swipeScript = GetComponent<SwipeScript>();
		}

		// Update is called once per frame
		void Update()
		{
			if (GameManeger.GetState() == GameManagerScript.STATE.PLAY || GameManeger.GetState() == GameManagerScript.STATE.SHORT_TUTORIAL || GameManeger.GetState() == GameManagerScript.STATE.CLEAR)
			{
				if (touchScript.IsPray() == false)
				{
					Singleton<SoundManagerScript>.instance.PlaySE("se_walk", walk);
				}

				transform.rotation = swipeScript.GetRotation();
			}
			else if (GameManeger.GetState() == GameManagerScript.STATE.GAME_OVER)
				this.enabled = false;
		}

	}
}