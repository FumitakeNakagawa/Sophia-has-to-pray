﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace main
{
	public class SwipeScript : MonoBehaviour
	{

		enum STATE
		{
			START,
			CONITNUE,
			END,
            WAIT,
		};
		STATE state;

		public enum DIRECT : int
		{
			LEFT,
			//RIGHT,
			CENTER,
			RIGHT,
			//LEFT,
			DOWN,

			DIRECT_MAX,
		}

		[SerializeField]
		main.LightPowerScript LPS;

		[SerializeField, Header("回転角")]
		[Header("0:左 1:真中 2:右 3:後")]
		Vector3[] offsetAngle = new Vector3[(int)DIRECT.DIRECT_MAX];

		[SerializeField]
		Quaternion[] offset;

		[SerializeField]
		float speed;

		[SerializeField]
		GameObject Swipe;

		//タッチ開始位置･終端位置
		Vector2 TouchStart, TouchEnd;

		//スワイプ(フリック)の長さ
		float length;

		//Slerpのt
		public float t;

		//今の向いている方向のオフセットのインデックス
		DIRECT nowIndex;
		//次に向く方向のオフセットのインデックス
		DIRECT nextIndex;
		//後ろ向いたときの前方向のインデックス
		DIRECT frontIndex;

		public DIRECT GetNowIndex() { return nowIndex; }
		//Slerp中か
		bool slerp;
		//後ろ向いているときか
		bool backCam;

		//ダブルタップされたか
		bool doubleTap;

		Quaternion rotation;
		Quaternion frontCam;

		main.GyroSensorScript gyroScript;
		[SerializeField]
		SliderScript slider;

		[SerializeField]
		UIArea UIArea;

		main.TouchScript touchScript;

		[SerializeField]
		GameManagerScript GMS;
		bool TouchUI;

		public bool IsSlerp() { return slerp; }
        public void SetNextIndex( DIRECT index) { nextIndex = index;t = 0f;slerp = true; }
		// Use this for initialization
		void Start()
		{

			slerp = false;
			state = STATE.START;
			nextIndex = nowIndex = DIRECT.CENTER;
			offset = new Quaternion[offsetAngle.Length];
			for (int index = 0; index < offset.Length; index++)
			{
				Vector3 v = offsetAngle[index];
				offset[index] = Quaternion.Euler(v.x, v.y, v.z);
			}

			rotation = new Quaternion(0, 0, 0, 1);
			backCam = false;
			doubleTap = false;
			frontCam = transform.rotation;
			t = 1;

			gyroScript = GetComponent<main.GyroSensorScript>();
			touchScript = GetComponent<main.TouchScript>();
			GMS = GetComponent<main.PlayerScript>().GetGameManager();

			TouchUI = false;
		}

		string str;
		// Update is called once per frame
		void Update()
		{
			//if (touchScript.IsPray()) return;

			Vector2 v = new Vector2(0, 0);


			if (!slerp)
			{
                //スワイプ
                //switch (state)
                //{
                //	case STATE.START:
                //		doubleTap = false;
                //		if (Input.touchCount == 1)
                //		{
                //			TouchStart = Input.GetTouch(0).position;
                //			state = STATE.CONITNUE;
                //		}
                //		break;
                //	case STATE.CONITNUE:
                //		if (UIArea.Pressed) TouchUI = true;
                //		if (slider.Pressed) TouchUI = true;

                //		if (Input.touchCount <= 0)
                //			state = STATE.END;
                //		else
                //			TouchEnd = Input.GetTouch(0).position;
                //		break;
                //	case STATE.END:
                //		if (TouchUI) TouchStart = TouchEnd = Vector2.zero;
                //		v = TouchEnd - TouchStart;
                //		length = Vector2.Distance(TouchEnd, TouchStart);
                //		state = STATE.START;
                //		slerp = true;
                //		TouchUI = false;

                //		break;
                //}

                //スワイプ
                switch (state)
                {
                    case STATE.START:
                        doubleTap = false;
                        if (Input.touchCount == 1)
                        {
                            if (Input.GetTouch(0).phase == TouchPhase.Moved)
                            {
                                TouchStart = Input.GetTouch(0).position;
                                state = STATE.CONITNUE;
                            }
                        }
                        break;
                    case STATE.CONITNUE:
                        if (UIArea.Pressed) TouchUI = true;
                        if (slider.Pressed) TouchUI = true;

                        if (touchScript.IsPray())
                            state = STATE.WAIT;
                        if (Input.GetTouch(0).phase == TouchPhase.Ended)
                            state = STATE.END;
                        else
                            TouchEnd = Input.GetTouch(0).position;
                        break;
                    case STATE.END:
                        if (TouchUI) TouchStart = TouchEnd = Vector2.zero;
                        v = TouchEnd - TouchStart;
                        length = Vector2.Distance(TouchEnd, TouchStart);
                        state = STATE.START;
                        slerp = true;
                        TouchUI = false;

                        break;
                    case STATE.WAIT:
                        if (!touchScript.IsPray())
                            state = STATE.START;
                        break;
                }
            }

			if (Mathf.Abs(v.x) > Mathf.Abs(v.y)) v.y = 0;
			else v.x = 0;

			if (v.x < 0 && length > 200f)
			{
				if (nowIndex == DIRECT.RIGHT || nowIndex == DIRECT.DOWN) return;
				nextIndex = nowIndex + 1;
				//nextIndex = nowIndex + 1;
				t = 0.0f;
				Singleton<SoundManagerScript>.instance.PlaySE("se_swipe", Swipe);
			}
			else if (v.x > 0 && length > 200f)
			{
				if (nowIndex == DIRECT.LEFT || nowIndex == DIRECT.DOWN) return;
				nextIndex = nowIndex -1;
				//nextIndex = nowIndex - 1;
				t = 0.0f;
				Singleton<SoundManagerScript>.instance.PlaySE("se_swipe", Swipe);
			}
			if (GMS.GetDifficulty() == GameManagerScript.DIFFICULTY.HARD)
			{
				if (v.y < 0 && length > 200f)
				{
					if (nowIndex != DIRECT.DOWN)
					{
						frontIndex = nowIndex;
						nextIndex = DIRECT.DOWN;
					}
					else
					{
						nextIndex = frontIndex;
					}
					t = 0.0f;
					Singleton<SoundManagerScript>.instance.PlaySE("se_swipe", Swipe);
				}
				else if (v.y > 0 && length > 200f)
				{
					if (nowIndex != DIRECT.DOWN)
					{
						frontIndex = nowIndex;
						nextIndex = DIRECT.DOWN;
					}
					else
					{
						nextIndex = frontIndex;
					}
					t = 0.0f;
					Singleton<SoundManagerScript>.instance.PlaySE("se_swipe", Swipe);
				}
			}

			if (t >= 1.0f)
			{
				t = 1f;
				nowIndex = nextIndex;
				slerp = false;
			}

			float frame = speed * Time.deltaTime;
			t += frame;
			Quaternion q1;
			Quaternion q2;
			q1 = offset[(int)nowIndex];
			q2 = offset[(int)nextIndex];

			t = Mathf.Min(1.0f, t);
			rotation = Quaternion.Slerp(q1, q2, t);
			str = "now:" + nowIndex.ToString() + "next:" + nextIndex.ToString();

		}

		private void OnGUI()
		{
			GUIStyle style = new GUIStyle();
			style.fontSize = 40;
			style.normal.textColor = Color.white;
			//GUI.Label(new Rect(0, 300, 100, 100), str, style);
		}

		public Quaternion GetRotation() { return rotation; }
		public bool IsBackCam() { return backCam; }
	}

}