﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace main
{
	public class DistUI : MonoBehaviour
	{
		//プレイヤーの場所
		[SerializeField]
		Transform PlayerPosition;

		//ゴール地点
		[SerializeField]
		Transform GoalPosition;

		//ゲームマネージャー
		[SerializeField]
		GameManagerScript gameManagerScript;

		//進行状況
		[SerializeField]
		int process;

		//分割数
		[SerializeField]
		int[] cut;

		int nowIndex;
		//最大距離
		float MaxDist;

		[SerializeField]
		Rect[] FillOffset;

		[SerializeField]
		GameObject[] footprintObject;//足跡

		void Start()
		{
			MaxDist = Vector3.Distance(GoalPosition.position, PlayerPosition.position);

			float per = (int)100 / (cut.Length - 1);
			for (int index = 0; index < cut.Length; index++)
			{
				cut[index] = (int)per * index;
			}
			nowIndex = 0;
			cut[cut.Length - 1] -= 4;
		}

		void Update()
		{

			process = (int)((1f - Percentage()) * 100);
			for (int index = nowIndex; index < cut.Length; index++)
			{
				if (index == 0) continue;
				if (process >= cut[index])
				{
					footprintObject[index].SetActive(true);
					nowIndex = index;
					footprintObject[nowIndex - 1].SetActive(false);
				}
			}
			if (gameManagerScript.GetState() == GameManagerScript.STATE.CLEAR)
			{

			}
		}

		float Percentage()
		{
			float dist = Vector3.Distance(GoalPosition.position, PlayerPosition.position);
			float percent = dist / MaxDist;
			return percent;
		}

	}
}