﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class DrawDifficult : MonoBehaviour
{

    Text text;
    [SerializeField]
    main.GameManagerScript gameManager;

    [SerializeField]
    Tutorial.GameManager_TutorialScript gameTutorial;
    // Use this for initialization
    void Start()
    {
        text = GetComponent<Text>();

        string sceneName;
        if (gameManager)
            sceneName = gameManager.GetDifficulty().ToString();
        else if (gameTutorial)
            sceneName = gameTutorial.GetDifficulty().ToString();

        text.text = SceneManager.GetActiveScene().name;
    }

    // Update is called once per frame
    void Update()
    {

    }
}
