﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System;

public class SliderScript : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
	[SerializeField]
	GameObject Slid;

	Slider slider;
	PointerEventData pointEventData;

	float nowValue;

	public bool Pressed;
	[SerializeField]
	main.TouchScript touchScript;
	
	// Use this for initialization
	void Start()
	{
		slider = GetComponent<Slider>();

		nowValue = slider.value;
		Pressed = false;
	}

	// Update is called once per frame
	void Update()
	{
		if (touchScript.IsPray()) slider.interactable = false;
		else slider.interactable = true;
		if(slider.value!= nowValue)
		{
			Singleton<SoundManagerScript>.instance.PlaySE("se_slid", Slid);
		}
		nowValue = slider.value;
	}

	public void OnPointerDown(PointerEventData data)
	{
		Pressed = true;
	}

	public void OnPointerUp(PointerEventData eventData)
	{
		Pressed = false;
		//throw new NotImplementedException();
	}
}
