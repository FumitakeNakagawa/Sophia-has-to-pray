﻿using System.Collections;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.UI;

namespace main
{
    public class FadeScript : MonoBehaviour
    {
        Color Color;

        [SerializeField]
        TouchScript touchSprict;

        [SerializeField]
        GameManagerScript GameManagerScript;

        float Alpha;
        [SerializeField, Range(1.0f, 255.0f), Header("フェードする時間(小さいほど短い)")]
        float FadeTimer;

        [SerializeField, Range(1.0f, 180.0f), Header("フェード開始までの時間")]
        float timer;

        Image image;

        float FramePerPlus;

        bool FadeEnd;

        [SerializeField]
        float startFadeSpeed;

        bool startFadeEnd;
        public bool IsStartFadeEnd() { return startFadeEnd; }
        // Use this for initialization
        void Start()
        {
            Color = new Color(0, 0, 0, 1);
            FramePerPlus = 1 / FadeTimer;
            FadeEnd = false;

            startFadeEnd = false;
            image = GetComponent<Image>();
        }

        // Update is called once per frame
        void Update()
        {
            if (GameManagerScript.GetState() == GameManagerScript.STATE.STANDBY)
            {
                Color.a -= startFadeSpeed * Time.deltaTime;
                Color.a = Mathf.Max(0.0f, Color.a);
                if (Color.a <= 0)
                    startFadeEnd = true;
            }
            else if (GameManagerScript.GetState() == GameManagerScript.STATE.PLAY|| GameManagerScript.GetState() == GameManagerScript.STATE.SHORT_TUTORIAL)
            {
                if (touchSprict)
                {
                    if (touchSprict.IsPray())
                        Color.a = 0.8f;
                    else
                        Color.a = 0.0f;

                }
            }

            else if (GameManagerScript.GetState() == GameManagerScript.STATE.CLEAR)
            {
                //Alpha += FramePerPlus;
                //Color = new Vector4(1, 1, 1, Alpha);
                FadeEnd = true;
            }


            else if (GameManagerScript.GetState() == GameManagerScript.STATE.GAME_OVER)
            {
                if (--timer <= 0)
                {
                    Alpha += FramePerPlus;
                    Color = new Color(0, 0, 0, Alpha);
                }
            }

            if (Alpha > 1.0f)
            {
                Alpha = 1.0f;
                Color.a = Alpha;
                FadeEnd = true;
            }

            image.color = Color;
        }

        public bool IsFadeEnd() { return FadeEnd; }
    }
}