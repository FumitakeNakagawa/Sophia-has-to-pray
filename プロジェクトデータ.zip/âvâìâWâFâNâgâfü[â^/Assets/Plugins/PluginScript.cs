﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PluginScript : MonoBehaviour
{
    AndroidJavaClass plugin = null;
    static AndroidJavaObject m_obj = null;
    public static GameObject m_instance;
    private GUIStyle labelFPS;
	public float proximityValue;
    float proximityFg;

    // Use this for initialization
    void Start()
    {
        proximityFg = 3.0f;
        m_instance = gameObject;

        labelFPS = new GUIStyle();
        labelFPS.fontSize = Screen.height * 2 / 15;
        labelFPS.normal.textColor = Color.white;

        plugin = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        m_obj = plugin.GetStatic<AndroidJavaObject>("currentActivity");
    }

    // Update is called once per frame
    void Update()
    {
        proximityValue = CallProximitySencsor();
        //proximityFg = m_obj.Call<float>("getProximityFg");

        //CallVibrate(1000);
    }

    public static float CallProximitySencsor()
    {
        if (m_obj == null) return 9999.0f;
        float value = 99.0f;
        if (m_obj != null)
        {
            value = m_obj.Call<float>("getProximitySensor");
        }
        else
        {
            print("取得失敗");
        }

        return value;
    }

    //バイブレーション(time(ms))
    public static void CallVibrate(long time)
    {
        if (m_obj == null) return;
        m_obj.Call("Vibrate", time);
    }

    //バイブレーションを止める
    public static void CallVibrateCancel()
    {
        if (m_obj == null) return;
        m_obj.Call("VibrateCancel");
    }

    public void OnGUI()
    {
        //if (m_obj == null)
        //{
        //    string text = string.Empty;
        //    text = string.Format("失敗");

        //    GUI.Label(new Rect(0, 0, 200, 200), text, labelFPS);
        //}
        //else
        //{
        //    string text = string.Empty;
        //    text = string.Format("成功");

        //    GUI.Label(new Rect(0, 0, 200, 200), text, labelFPS);
        //}

        string text = string.Empty;
        text = string.Format("" + proximityValue);

        //GUI.Label(new Rect(0, 0, 200, 200), text, labelFPS);
    }
}